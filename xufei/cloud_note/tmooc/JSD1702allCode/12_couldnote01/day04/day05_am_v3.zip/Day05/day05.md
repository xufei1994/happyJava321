# 云笔记

## 笔记本列表

### 3. 控制器

1. 添加控制器父类AbstractController, 封装公共的异常处理方法:

		public abstract class AbstractController {
			/**
			 * 在其他控制器方法执行出现异常时候, 执行
			 * 异常处理方法 handleException
			 */
			@ExceptionHandler(Exception.class)
			@ResponseBody
			public Object handleException( Exception e){
				e.printStackTrace();
				return new JsonResult(e);
			}
		
		}

	>重构 UserController, 使其继承于 AbstractController

		略...

2. 创建控制器类 NotebookController:

		@RequestMapping("/notebook")
		@Controller
		public class NotebookController extends AbstractController {
			
			@Resource
			private NotebookService notebookService;
			
			@RequestMapping("/list.do")
			@ResponseBody
			public JsonResult list(String userId){
				List<Map<String, Object>> list=
					notebookService.listNotebooks(userId);
				return new JsonResult(list);
			}
		}

3. 测试

		http://localhost:8080/note/notebook/list.do?userId=52f9b276-38ee-447f-a3aa-0d54e7a736e4

		http://localhost:8080/note/notebook/list.do?userId=abc

		http://localhost:8080/note/notebook/list.do

	> 测试结果体现了控制器能够利用父类的异常处理方法处理异常情况.

### 4. 表现层脚本编程

1. 更新log_in.html 引入cookie操作API:

		<script type="text/javascript" src="scripts/cookie_util.js"></script>

2. 更新 login.js 的loginAction方法, 在登录成功时候将userId保存到cookie中:

		...
		//登录成功以后将userId保存到cookie中
		addCookie("userId", user.id); 
		...
	
3. 在edit.html添加JS脚本:

		<script type="text/javascript"
			src="scripts/cookie_util.js"></script> 
		
		<script type="text/javascript"
			src="scripts/note.js"></script>

	> 为了提高页面的用户体验, 减少页面加载延迟, 将脚本在页面后部加载.

4. 添加scripts/note.js 文件:

		var SUCCESS = 0;
		var ERROR = 1;
		
		$(function(){
			
			var userId = getCookie('userId');
			console.log(userId);
			
		});
			
	> scripts/note.js 编码一定是 utf-8 

5. 测试: 登录以后可以再edit.html 的控制台上能够看到 userId, 可以通过浏览器的控制台检查cookie保存情况:

	![](cookie.png)

