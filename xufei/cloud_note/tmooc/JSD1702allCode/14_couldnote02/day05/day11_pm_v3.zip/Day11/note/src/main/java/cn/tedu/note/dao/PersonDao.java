package cn.tedu.note.dao;

import cn.tedu.note.entity.Person;

public interface PersonDao {

	int addPerson(Person person);

}
