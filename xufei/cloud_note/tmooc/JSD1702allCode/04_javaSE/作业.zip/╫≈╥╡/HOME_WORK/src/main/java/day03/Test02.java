package day03;
/**
 * 将当前系统时间以"yyyy-MM-dd HH:mm:ss"格式输出
 * @author Xiloer
 *
 */
public class Test02 {

}
