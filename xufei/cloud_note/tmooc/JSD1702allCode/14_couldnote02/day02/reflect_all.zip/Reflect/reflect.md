# 反射

## 什么是反射

反射是Java提供的动态执行机制, 可以动态加载类, 动态创建对象, 动态访问属性, 动态调用方法..

静态执行: Java代码经过编译以后就确定的执行次序, 称为静态执行次序

	Foo foo = new Foo();
	foo.test();

动态执行: 在运行期间才确定创建那个类的对象, 执行那个方法!

Java 反射API可以实现动态执行!

案例: 执行某个类中全部的以test为开头的方法. (必须使用使用反射实现)

反射:

1. 反射是Java提供的API, 接受API的提供的功能!
2. 是Java底层的执行机制.

## 反射功能

### 动态加载类


	Class cls = Class.forName(类名)

作用: 将类名对应的类加载到方法区, 如果类名错误则抛出异常.


### 动态创建对象

	Object obj = cls.newInstance();

特点:

- 动态创建对象
- 可以创建任何对象
- cls对应的类必须有无参数构造器!!!
- 如果没有无参数构造器则抛出异常!
- 反射API利用Constructer API支持有参数构造器, 略...

### 反射可以查询类中的方法

可以返回类中声明的全部方法信息

	Method[] methods = cls.getDeclaredMethods(); 
	for(Method m:methods){
		System.out.println(m);//输出方法信息
	}

	Declared 声明的
	Method 方法

### 动态执行方法

执行方法: 

1. 必须有对象
2. 找到对象对应的类型方法信息
	- 方法信息在类上查找

案例:

	Method m = cls.getDeclaredMethod(方法名);//在类信息上查找一个方法信息
	//m 代表 cls类上的一个方法信息
	Object obj=cls.newInstance();//动态创建对象
	//动态调用(invoke)方法
	Object val = m.invoke(obj);

### 反射用途

1. Eclipse 的快捷菜单使用了反射, 利用反射发现了类的属性和方法
2. Spring 利用了反射
	- 动态加载类
	- 动态创建Bean
	- 动态注入属性, 包括私有属性注入
	- 动态解析注解
3. MyBatis 利用了反射
	- 查询时候, 动态了将查询结果利于反射注入到Bean返回
4. JUnit 使用了反射
5. 注解的解析使用了反射
6. Servlet调用使用了反射

	









































