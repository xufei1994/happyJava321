# API

## Java中如何比较两个对象

1. 默认比较大小Comparable
	- Java 中定义了一个接口  Comparable
	- 包含比较方法compareTo
		- 返回正数， 第一个对象大
		- 返回负数， 第一个对象小
		- 返回0数， 两个数一样
	- Java中可以比较大小的API都实现了这个接口
		- String 
		- Date 
		- 包装类
		- 等
	- 案例


			public class Demo01 {
				public static void main(String[] args) {
					String s1 = "田";//30000
					String s2 = "中";//20013
					String s3 = "abcd";
					int n1 = s1.compareTo(s2);
					int n2 = s2.compareTo(s1);
					int n3 = s1.compareTo(s3); 
					System.out.println(n1);
					System.out.println(n2);
					System.out.println(n3);
					
				}
			}

2. 定义比较大小  Comparator 
	- 声明了用于比较任意对象的方法 compare

	- 案例：

			public class Demo03 {
				public static void main(String[] args) {
					Product p1 = 
						new Product("新西兰空气", 5.9);
					Product p2 = 
						new Product("加勒比海海水", 6);
					Product p3 = 
						new Product("喜马拉雅山雪", 6);
					ByWeight byWeight = new ByWeight();
					int n1 = byWeight.compare(p1, p2);
					int n2 = byWeight.compare(p2, p1);
					int n3 = byWeight.compare(p2, p3);
					System.out.println(n1);
					System.out.println(n2);
					System.out.println(n3);
					}
			}
			/*
			 * 按照商品重量进行自定义比较
			 */
			class ByWeight 
				implements Comparator<Product>{
				public int compare(
						Product o1, Product o2) {
					double val = o1.weight-o2.weight;
					if(val>0){return -1;}
					if(val<0){return 1;}
					return 0;
				}
			}
			class Product{ //产品
				String name;
				double weight;//重量
				public Product(
						String name, double weight) {
					this.name = name;
					this.weight = weight;
				}
				public String toString() {
					return "Product [name=" + name + ", weight=" + weight + "]";
				}
			}

## 自然排序

	/**
	 * 对可以比较大小的对象进行自然排序 
	 */
	public class Demo02 {
		public static void main(String[] args) {
			List<String> list = 
					new ArrayList<String>();
			list.add("Tom");
			list.add("Jerry");
			list.add("Andy");
			list.add("Lee");
			list.add("Mac");
			/*
			 * sort方法只能对List集合进行排序
			 * list集合中的元素需要实现Compatible
			 * 接口包含compareTo方法 
			 */
			Collections.sort(list);
			System.out.println(list); 
			
		}
	}

## 自定义排序

	/**
	 * 自定义比较与自定义排序 
	 *
	 */
	public class Demo03 {
		public static void main(String[] args) {
			Product p1 = 
				new Product("新西兰空气", 5.9);
			Product p2 = 
				new Product("加勒比海海水", 6);
			Product p3 = 
				new Product("喜马拉雅山雪", 6);
			ByWeight byWeight = new ByWeight();
			int n1 = byWeight.compare(p1, p2);
			int n2 = byWeight.compare(p2, p1);
			int n3 = byWeight.compare(p2, p3);
			System.out.println(n1);
			System.out.println(n2);
			System.out.println(n3);
		
			List<Product> list=
				new ArrayList<Product>();
			list.add(p3);
			list.add(p2);
			list.add(p1);
			list.add(new Product(
					"阿拉斯加的土", 2)); 
			//Java中的自定义排序
			//将集合中的元素按照给定的自定义比较器
			//的比较结果进行排序。
			Collections.sort(list, byWeight);
			System.out.println(list);
		}
	}
	/*
	 * 按照商品重量进行自定义比较
	 */
	class ByWeight 
		implements Comparator<Product>{
		public int compare(
				Product o1, Product o2) {
			double val = o1.weight-o2.weight;
			if(val>0){return -1;}
			if(val<0){return 1;}
			return 0;
		}
	}
	class Product{ //产品
		String name;
		double weight;//重量
		public Product(
				String name, double weight) {
			this.name = name;
			this.weight = weight;
		}
		public String toString() {
			return "Product [name=" + name + ", weight=" + weight + "]";
		}
	}

## Queue 队列

Java提供了Queue API，由LinkedList实现，用于处理先进先出的业务问题，如视频缓存队列

操作方法：

1. offer 将数据插入队列
2. peek 检查队列头部元素
3. poll 从队列拉出数据

![](1.png)

案例：
	 
	public class Demo04 {
		public static void main(String[] args) {
			Queue<String> queue = 
				new LinkedList<String>();
			System.out.println(queue);
			//offer将数据追加到队列中
			queue.offer("Tom");
			queue.offer("Jerry");
			queue.offer("Andy");
			System.out.println(queue); 
			//peek检查队首，元素并不出列
			String first = queue.peek();
			System.out.println(first);//Tom
			System.out.println(queue);//不变
			//poll 是拉出一个元素，元素出列
			String element=queue.poll();
			System.out.println(element);//Tom
			System.out.println(queue);
			//拉取队列中全部的数据
			while(! queue.isEmpty()){
				System.out.println(queue.poll());
			}
		}
	}

## Stack 栈

栈是后进先出的数据结构。

Java 利用Deque 接口提供了栈操作方法 push 和 pop，由LinkedList实现了Stack结构：

方法：

1. push 将数据压入栈
2. pop 将数据从栈中弹出 

案例：

	/**
	 * 后进先出的栈结构 
	 */
	public class Demo05 {
		public static void main(String[] args) {
			// Deque 接口中定义了 栈操作方法
			// LinkedList 实现了栈操作方法
			Deque<String> stack = 
				new LinkedList<String>();
			//栈提供了 push方法可以将数据“压”入栈中。
			stack.push("Tom");
			stack.push("Jerry");
			stack.push("Andy");
			//先压入的数据在栈的最底部
			System.out.println(stack);
			//出栈的顺序相反：后进先出
			while(! stack.isEmpty()){
				//利用pop可以从栈中弹出数据
				//弹出顺序与进入顺序相反
				String s = stack.pop();
				System.out.println(s); 
			}
		}
	}

