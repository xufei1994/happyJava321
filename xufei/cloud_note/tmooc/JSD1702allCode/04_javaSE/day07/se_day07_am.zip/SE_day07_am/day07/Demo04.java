package day07;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;

/**
 * 写出员工信息 
 */
public class Demo04 {
	public static void main(String[] args) 
		throws IOException{
		String file="abc/emp.dat";
		RandomAccessFile raf=
			new RandomAccessFile(file, "rw");
		write(raf, 0,"Tom", 10, "男", 100, new Date());
		write(raf, 1,"范传奇",30,"男",200,new Date());
		raf.close();
	}	
	public static void write(
			RandomAccessFile raf, //已经打开的文件
			int n, //n = 0 1 2 ... 行号
			String name, 
			int age,
			String sex,
			int salary,
			Date hiredate){
		
	}
}
