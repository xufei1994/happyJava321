package day02;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

import util.DBUtil;

public class TestDay02 {
	
	/**
	 * 测试DBUtil的方法
	 */
	@Test
	public void test1() {
		//假设浏览器传入的查询条件是
		int empno = 1815;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			System.out.println(conn);
			Statement smt = conn.createStatement();
			String sql = 
				"select * from emps_lhh "
				+ "where empno>" + empno;
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				System.out.println(rs.getInt("empno"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}

}














