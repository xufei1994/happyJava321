# 云笔记

## JSON 是什么

JSON 就是JS的一部分: JSON 是 JavaScript中的对象直接量语法, 用于声明JS对象.

如:
		
	var i = 5;
	var str = 'abc';
	var obj = {age:5, name:'Tom'};
	var ary = ['Tom','Jerry','Andy'];
	var list = [{name:"Tom",age:8},{name:"Jerry",age:9}];


符合JSON语法的字符串称为JSON字符串:

	var str = '{"name":"Tom","age":6}';
	var str = '["name","Tom","age"]';

如何将JSON字符串转换为JSON对象(JS对象)
	
	var obj = eval("("+str+")");

## 需求分析

软件= 数据结构+算法

## 设计数据的存储

1. 内存:  数据临时计算存储场所, 关闭电源就消失, 称为瞬态的
	- 运行内存
	- 分配的是对象  

2. 外存: (SSD固体硬盘, HDD机械硬盘, SD, 闪存, U盘), 关闭电源不消失, 称为持久状态
	- 存储容量  
	- 保存的是文件 单机(单线程)程序可以使用文件存储数据
	- 数据库(文件) 数据库管理系统,提供了并发访问管理! 适合多线程访问

> 云笔记采用数据库存储数据!

### 设计数据的存储

![](db.png)

ER 图:

![](note_db.png)


### MySQL的简单使用

1. 使用MySQL命令行工具
	- Windows 用户使用: MySQL Client, 输入密码
	- Linux: 
	
			mysql -u用户名 -p密码
			mysql -uroot -p

2. 显示数据库命令

		show databases;

3. 创建数据库命令

		create database 数据库名;

4. 删除数据库命令

		drop database 数据库名;

5. 切换当前数据库
	
		use 数据库名
		use mysql

6. 显示当前数据库中的全部表

		show tables;

7. 建表语句, 在当前数据库中创建表

		create table 表名 (列的声明...)

8. 设置当前命令行窗口的编码: 设置当前窗口的文本编码为UTF-8

		set names utf8;

9. 执行sql脚本命令: 执行文本文件中的一批SQL命令.
	- 如果SQL文件是UTF-8编码的, 就必须先执行 	set names utf8;
	
		source 文本文件的路径名;
		source D:\Robin\Note\note_ziliao\cloud_note.sql
		source /home/soft01/note_ziliao/cloud_note.sql
		
	> 请注意: 一定要清楚路径, 保障路径的正确性!!!

案例: 执行脚本建立数据表:

	source /home/soft01/note_ziliao/cloud_note.sql
	show databases;
	use cloud_note;
	show tables;


案例: 创建一张表, 并且插入数据. 

	create database demo;
	use demo
	create table MyTable(id int, name varchar(100));
	insert into MyTable (id, name) values (1, 'Tom');
	insert into MyTable (id, name) values (2, 'Jerry');
	select id, name from MyTable;
	drop table MyTable;
	drop database demo;


## 登录功能

程序 = 数据结构 + 算法

编程思路:

0. 搞清楚业务需求.
1. 考虑数据如何存储.
2. 如何操作数据才能达到业务目的
	- 设计SQL
3. 编程: 将业务功能和数据操作整合起来, 如何编程才能执行SQL操作数据




	









 




