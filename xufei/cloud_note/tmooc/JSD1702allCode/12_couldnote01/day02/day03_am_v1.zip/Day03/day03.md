# 云笔记

## 登录(续)

### 2. 业务层

1. 创建业务层接口

		public interface UserService {
			/**
			 * 登录功能, 登录成功返回用户信息, 登录失败
			 * 则抛出异常.
			 * @param name 用户名 
			 * @param password 密码
			 * @return 如果登录成功就返回登录用户信息
			 * @throws UserNotFoundException 用户不存在
			 * @throws PasswordException 密码错误
			 */
			User login(String name, String password)
				throws UserNotFoundException,
				PasswordException;
		}

2. 创建业务异常类

		public class UserNotFoundException extends RuntimeException {
			private static final long serialVersionUID = 4180191103842028379L;
		
			public UserNotFoundException() {
			}
		
			public UserNotFoundException(String message) {
				super(message);
			}
		
			public UserNotFoundException(Throwable cause) {
				super(cause);
			}
		
			public UserNotFoundException(String message, Throwable cause) {
				super(message, cause);
			}
		
			public UserNotFoundException(String message, Throwable cause, boolean enableSuppression,
					boolean writableStackTrace) {
				super(message, cause, enableSuppression, writableStackTrace);
			}
		
		}
		
		
		public class PasswordException extends RuntimeException {
			private static final long serialVersionUID = 7097581917306952312L;
		
			public PasswordException() {
			}
		
			public PasswordException(String message) {
				super(message);
			}
		
			public PasswordException(Throwable cause) {
				super(cause);
			}
		
			public PasswordException(String message, Throwable cause) {
				super(message, cause);
			}
		
			public PasswordException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
				super(message, cause, enableSuppression, writableStackTrace);
			}
		
		}

3. 实现业务层方法 

		@Service("userService")
		public class UserServiceImpl 
			implements UserService {
			
			@Resource
			private UserDao userDao;
			
			public User login(String name, String password) 
					throws UserNotFoundException, 
					PasswordException {
				if(password==null ||
						password.trim().isEmpty()){
					throw new PasswordException("密码空");
				}
				if(name==null || name.trim().isEmpty()){
					throw new UserNotFoundException("用户名空");
				}
				User user = userDao.findUserByName(
						name.trim());
				if(user==null){
					throw new UserNotFoundException("name错误");
				}
				if(password.trim().equals(user.getPassword())){
					return user;
				}
				throw new PasswordException("密码错误");
			}
		}

4. 配置Spring, 扫描业务层组件的注解 conf/spring-service.xml:

		<context:component-scan  base-package="cn.tedu.note.service"/>

5. 测试	
	
		public class UserServiceTest {
			
			ClassPathXmlApplicationContext ctx;
			
			@Before 
			public void initCtx(){
				ctx = new ClassPathXmlApplicationContext(
						"conf/spring-mvc.xml",
						"conf/spring-mybatis.xml",
						"conf/spring-service.xml");
			}
			@After
			public void close(){
				ctx.close();
			}
		
			@Test
			public void testLogin(){
				String name = "demo";
				String password = "123";
				UserService service = 
					ctx.getBean("userService",
					UserService.class);
				User user = service.login(
					name, password);
				System.out.println(user); 
			}
		}

	> 为了测试, 需要更像数据库, 更新数据库的SQL
	
		use cloud_note;
		
		update cn_user 
		set cn_user_password='123' 
		where cn_user_name='demo';
		
		select cn_user_password 
		from cn_user 
		where cn_user_name='demo';