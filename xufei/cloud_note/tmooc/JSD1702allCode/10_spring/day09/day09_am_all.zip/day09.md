# 1. Spring集成MyBatis (方式二 了解)
## (1)集成步骤
	step1.导包。
	spring-webmvc,mybatis,mybatis-spring,
	dbcp,ojdbc,spring-jdbc,junit。

	step2.添加spring配置文件。
	注：不再需要MyBatis的配置文件,可以在spring的配置文件里面
	添加SqlSessionFactoryBean来代替。

	step3.实体类
	step4.映射文件
		注：namespace不再要求等于接口名。
	step5.DAO接口
		注：接口方法没有特定要求
	step6.写一个DAO接口的实现类
		注：可以注入SqlSessionTemplate。
![](st.png)	
![](st2.png)

# 2. 使用Spring集成MyBatis的方式重写AdminDAO
	step1. 导包
		需要添加 mybatis,mybatis-spring,spring-jdbc
	step2. 在配置文件当中，添加
		SqlSessionFactoryBean
	step3. 实体类Admin 
		要注意属性与表的字段名不一样，建议用别名解决
	step4. 映射文件
		AdminMapper.xml
			namespace="cn.tedu.netctoss.dao.AdminDAO"
		<select id="findByAdminCode" 
			parameterType="java.lang.String"
			resultType="cn.tedu.netctoss.entity.Admin">
			SELECT ...
		</select>
	step5. Mapper映射器 (AdminDAO)
		不用写了 
	step6. 配置MapperScannerConfigurer 
	step7. 测试 AdminDAO					