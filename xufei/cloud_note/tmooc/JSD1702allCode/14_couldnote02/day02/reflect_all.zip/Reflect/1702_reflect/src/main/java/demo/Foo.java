package demo;

public class Foo {
	
	public String hello(){
		return "Hello World!";
	}
	
	public int demo(){
		return 100;
	}
}
