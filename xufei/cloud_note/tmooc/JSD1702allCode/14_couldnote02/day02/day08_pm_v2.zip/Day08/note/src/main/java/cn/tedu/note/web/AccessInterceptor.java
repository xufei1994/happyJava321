package cn.tedu.note.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class AccessInterceptor implements 
	HandlerInterceptor {
	public boolean preHandle(
			HttpServletRequest req,
			HttpServletResponse res, 
			Object handle) throws Exception {
		
		String path=req.getRequestURI();
		System.out.println("Interceptor:"+path);
		
		return true;//放过请求
	}
	
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
	}
	
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
	}
}
