# 一.图片轮播
![](1.png)

# 二.省市联动
![](2.png)

# 画图工具
- FastStone Capture