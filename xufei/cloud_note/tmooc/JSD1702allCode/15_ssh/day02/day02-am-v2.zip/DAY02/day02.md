Servlet和filter的区别
概念:
Servlet:运行在服务器端的程序.动态生成页面
filter:是一段可复用的程序.它可以对请求和响应进行处理,但不能生成请求和响应.

生命周期:
Servlet:
web服务器启动的时候,发出第一次请求的时候,init()初始化
针对访问doPost()方法
服务器停止,调用destroy()销毁实例

Filter:
启动服务器,调用init()实例化
doFilter()方法
服务器停止,调用destroy()销毁实例

服务器端字符为什么进行编码?

内存当中的char占16位(比较大),网络传输的单位是8位(比较小),只有对内存中的数据进行拆分,才能够进行传输,拆分的过程叫做编码.

区别?

gbk:本土最优的编码方案,2万+,汉字占2字节

utf-8:国际化的最优编码方案,10万+,中文占3个字节


Struts2+spring整合/result常用类型/拦截器

struts2-spring-plugin

为什么?通过spring管理Struts2的组件,实现注入

怎么整合?

1.创建项目
2.导包:struts2-spring-plugin  struts2-core
3.配置文件:web.xml spring-context.xml
















