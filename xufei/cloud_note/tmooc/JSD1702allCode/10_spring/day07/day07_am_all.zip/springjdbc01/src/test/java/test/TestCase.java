package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.EmployeeDAO;
import entity.Employee;

public class TestCase {
	@Test
	public void test1(){
		String config = "spring-jdbc.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		EmployeeDAO dao = 
				ac.getBean("employeeDAO",
						EmployeeDAO.class);
		Employee e = new Employee();
		e.setName("Giving King");
		e.setAge(22);
		dao.save(e);
		
		
		
	}
}



