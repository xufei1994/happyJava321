package day07;
/**
 * 使用缓冲流复制myfile.txt文件为myfile_cp2.txt
 * @author Xiloer
 *
 */
public class Test02 {

}
