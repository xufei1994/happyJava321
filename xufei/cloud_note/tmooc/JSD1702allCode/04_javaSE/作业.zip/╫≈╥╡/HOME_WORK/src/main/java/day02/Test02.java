package day02;
/**
 * 将字符串123,456,789,012根据","拆分，并输出拆分后的每一项
 * @author Xiloer
 *
 */
public class Test02 {

}
