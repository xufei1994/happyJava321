# 一.JDBC对事务的支持
## 1.默认管理方式
- JDBC默认会自动管理事务
- 每次调用executeUpdate()时它会自动commit
> 一个业务内只包含一次DML

## 2.手动管理方式
- 取消自动: conn.setAutoCommit(false)
- 手动提交: conn.commit()
- 手动回滚: conn.rollback()