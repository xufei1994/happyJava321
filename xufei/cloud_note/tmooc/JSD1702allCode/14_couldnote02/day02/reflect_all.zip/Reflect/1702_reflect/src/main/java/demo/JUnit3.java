package demo;

import java.lang.reflect.Method;
import java.util.Scanner;

/**
 * JUnit 3 原型
 */
public class JUnit3 {
	public static void main(String[] args) 
		throws Exception{
		//动态加载类
		//动态创建对象
		//找到类中全部的方法
		//遍历查找哪些方法以test为开头
		//执行这些方法
		Scanner in = new Scanner(System.in);
		System.out.print("输入类名:");
		String className = in.nextLine();
		Class cls = Class.forName(className);
		Object obj = cls.newInstance();
		Method[] methods = 
				cls.getDeclaredMethods();
		for(Method method: methods){
			//检查方法名是否以test为开头
			String name = method.getName();
			if(name.startsWith("test")){
				//调用方法
				method.setAccessible(true); 
				method.invoke(obj);
			}
		}
	}
}







