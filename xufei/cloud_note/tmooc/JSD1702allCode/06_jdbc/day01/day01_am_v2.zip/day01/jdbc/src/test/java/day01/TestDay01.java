package day01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

/**
 * Junit：
 * 1.允许一个类中的多个方法都能单独执行
 * 2.需要在方法前加@Test才能让它单独执行
 * 3.方法必须是公有的,无返回值的,无参的
 * 4.在正式的WEB项目中,代码需要拷贝到服务器
 *   里执行,Eclipse在拷贝代码时会抛弃测试
 *   代码,所以Junit的包将来也会被抛弃,就无需
 *   使用maven来导入这样的包了
 */
public class TestDay01 {

	/**
	 * 如何创建连接
	 */
	@Test
	public void test1() {
		System.out.println(1);
		Connection conn = null;
		try {
			//注册驱动
			Class.forName(
				"oracle.jdbc.driver.OracleDriver");
			//创建连接
			conn = 
				DriverManager.getConnection(
				"jdbc:oracle:thin:@192.168.201.227:1521:orcl", 
				"openlab", "open123");
			System.out.println(conn);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	@Test
	public void test2() {
		System.out.println(2);
	}
	
}














