package day01;

public class Demo14 {
	public static void main(String[] args) {
		int n = 0x20;
		//valueOf 将n转换为10进制字符串
		String s = String.valueOf(n);
		System.out.println(s);//32
		
		System.out.println(n);//32
		double pi = 3.1415926535897932384626;
		System.out.println(pi); 
	}
}


