package cn.tedu.shoot;
/** 敌人 */
public interface Enemy {
	/** 得分 */
	public int getScore();
}
















