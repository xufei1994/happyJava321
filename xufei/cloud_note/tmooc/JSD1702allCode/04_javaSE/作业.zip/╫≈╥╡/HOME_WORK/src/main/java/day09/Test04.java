package day09;
/**
 * 创建一个线程，每秒输出一次当前系统时间:yyyy-MM-dd HH:mm:ss
 * @author Xiloer
 *
 */
public class Test04 {

}
