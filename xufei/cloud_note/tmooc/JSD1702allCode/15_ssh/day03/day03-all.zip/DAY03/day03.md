#Result常用类型
- dispatcher 转发
- redirectAction 重定向Action
- redirect 重定向URL
- Stream 用于图片的传输
- json Struts2-json-plugin

##JSON两种使用方式:

- 发送Action中的全部属性
  
		<result type="json"></result>

- 发送Action中的某一个属性

		<result type="json">  
		<param name="root">属性名<param></result>

#拦截器

##是什么?

java动态拦截Action调用的对象

请求-->filter-拦截点->Action-拦截点->result-->浏览器

##为什么?

适合封装通用的处理,便于复用,扩展

##怎么用?

- 创建拦截器

  需要实现interceptor接口

- 注册拦截器

		<pakage>下<interceptor name="aaa" class>

- 引用拦截器

		<action>下<interceptor-ref name="aaa" />

- 注意:

在使用Struts过程中,一旦引用了自定义的拦截器.那么框架默认引用的拦截器栈就被撤消,导致一些框架功能不能正常实现.


#valueStack:值栈

##是什么?

Struts中用于共享数据的数据结构


##作用:

- EL与valueStack的配合可以从控制器向页面传递值

- 针对某个请求的上下文对象,可以保存到值栈中.

##结构

- Contents:存数值(Action属性).栈结构

- Context:存储相关对象.Map结构

##访问方式:

- Contents:OGNL/EL表达式,自顶向下查询数据,匹配后,马上返回

- Context:#key value

##生命周期

当请求进入服务器的filter,创建valueStack对象;请求处理结束,valueStack对象被销毁.

#整合struts2+spring+mybatis

		create table user(id int primary key,name varchar(30))
		insert into user values(1,'JackSon')


		create table user_pwd(id int primary key,name varchar(30),
		password varchar(30))

		insert into user_pwd values(1,"Robin","123456")

#作业

- strus2+spring+mybatis 框架整合

- 以上的环境下实现登录功能(增加json)
































