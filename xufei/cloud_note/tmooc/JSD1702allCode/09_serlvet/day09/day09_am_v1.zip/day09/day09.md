# 一.session
## 1.基本用法
- 获得session: request.getSession()
- 存数据: session.setAttribute()
- 取数据: session.getAttribute()
- 删数据: session.removeAttribute()
- 销毁: session.invalidate()

## 2.超时时间
- 默认是30分钟
- 可以在配置文件中修改此时间

## 3.cookie禁用时session怎么办?
- 解决方案: URL重写

## 4.session销毁
![](1.png)