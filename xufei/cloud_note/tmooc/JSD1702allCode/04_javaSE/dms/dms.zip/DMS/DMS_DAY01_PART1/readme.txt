完成test包中Part1与Part2的相关方法，然后
替换到DMSClinet中的同名方法。

当全部完成后，运行DMSClient类，项目中应当
会出现两个文件:
1:last-position.txt，内容为:3720
2:log.txt,内容为10条日志信息

