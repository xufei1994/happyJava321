package cn.tedu.netctoss.dao;

import cn.tedu.netctoss.entity.Admin;

/**
 * 持久层实现
 */

public class AdminDAOJdbcImpl implements 
AdminDAO{
	
	public Admin findByAdminCode(
			String adminCode) {
		
		return null;
	}

}
