package day03;

public class Demo01 {
	public static void main(String[] args) {
		StringBuilder s = 
			new StringBuilder(
				"画上荷花和尚画");
		s.reverse();
		System.out.println(s); 
	}
}
