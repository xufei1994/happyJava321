package cn.tedu.dao;

import cn.tedu.User;

public interface UserDao {
	void save(User user);
}
