package day02;
/**
 * 检查手机号的规则
 * 
 *  15601035818
 *  008615601035818
 *  0086 15601035818
 *  +86  15601035818
 *  
 *  (0086|\+86)?\s*1\d{10}
 *  
 *
 */
public class Demo07 {

	public static void main(String[] args) {

	}

}
