package day03;
/**
 * Intger 极值
 */
public class Demo05 {
	public static void main(String[] args) {
		int max = Integer.MAX_VALUE;
		int min = Integer.MIN_VALUE;
		System.out.println(max);
		System.out.println(min);
		
		double dmax = Double.MAX_VALUE;
		System.out.println(dmax+1);
	}

}
