package day05;
/**
 * 创建一个队列，存入Integer类型元素1,2,3,4,5
 * 然后遍历队列并输出每个元素
 * @author Xiloer
 *
 */
public class Test01 {

}
