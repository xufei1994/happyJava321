package cn.tedu.note.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.tedu.note.dao.NoteDao;
import cn.tedu.note.service.NoteService;
import cn.tedu.note.service.NotebookNoteFoundExcepotion;

@Service("noteService")
public class NoteServiceImpl 
	implements NoteService{
	
	@Resource
	private NoteDao noteDao;
	
	public List<Map<String, Object>> listNotes(String notebookId) 
				throws NotebookNoteFoundExcepotion {
		
		return noteDao.findNotesByNotebookId(notebookId);
	}
}
