# 一.JDBC对事务的支持
## 1.默认管理方式
- JDBC默认会自动管理事务
- 每次调用executeUpdate()时它会自动commit
> 一个业务内只包含一次DML

## 2.手动管理方式
- 取消自动: conn.setAutoCommit(false)
- 手动提交: conn.commit()
- 手动回滚: conn.rollback()

## 3.什么是事务
- 满足如下4个特征的数据库访问叫事务:
- 原子性: 事务是一个完整的过程,要么都成功,要么都失败.
- 一致性: 事务访问前后数据一致,即收支平衡.
- 隔离性: 事务过程中的数据要隔离,不允许别人访问.
- 持久性: 事务一旦达成,就永久有效.
> 上述4句话是一个整体,构成了事务的特征.

# 二.批量添加数据
![](1.png)

# 三.获取自动生成的ID
## 1.反查ID
- insert into user values(seq.nextval,?,?)
- select * from user where username=?

## 2.记录ID
- select seq.nextval from dual  ->  id
- insert into user values(id,?,?)

## 3.让PS对象返回生成的ID(*)
- 详见案例

![](2.png)

# 四.JDBC对分页的支持
## 1.假分页(内存分页)
- 第1次查询时获取所有数据,并将其存入内存(List)
- 第N次查询时不再访问数据库,而是从内存中(List)取数
- 特点: 第1次查询巨慢,再次查询快,耗内存
> 适合数据量很小的小项目

## 2.真分页(物理分页)*
- 每次查询时都是获取一页的数据
- 使用分页的SQL进行查询
- 特点: 每次查询速度都一样,不耗内存
- 适合任意的项目

![](3.png)


# 五.DAO
![](4.png)


# 补充:JDBC中的日期类型
- 在JDBC中要使用java.sql下的日期类型
- java.sql.Date 年月日
- java.sql.Time 时分秒
- java.sql.Timestamp 年月日时分秒
> 上述日期都是java.util.Date的子类