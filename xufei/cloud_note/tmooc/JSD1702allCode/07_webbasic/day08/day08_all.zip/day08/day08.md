# 一.图片轮播
![](1.png)

# 二.省市联动
![](2.png)

# 三.加入购物车
![](3.png)

# 四.加法
![](4.png)

# 画图工具
- FastStone Capture