# 一.元素的显示方式
## 1.元素有哪些显示方式
### 1)块
- 有宽高,垂直排列
- h1,p,ol,ul,div,table,form

### 2)行内
- 无宽高,左右排列
- span,b,strong,i,em,u,del,a,label

### 3)行内块
- 有宽高,左右排列
- img,input,select,textarea

## 2.如何改变元素的显示方式
- 块: display:block;
- 行内: display:inline;
- 行内块: display:inline-block;
- 隐藏: display:none;

# 二.管理员列表-6
![](1.png)

