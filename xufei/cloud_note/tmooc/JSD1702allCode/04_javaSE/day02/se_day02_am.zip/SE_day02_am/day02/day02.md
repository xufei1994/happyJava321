# Java API

## String 和 StringBuilder

String是不变字符串： 对象不可改变，对象中的字符数组中的数据不可改变。

StringBuilder是可变字符串：对象封装的字符数组中的数据可以改变。

StringBuilder类型的操作性能好于Srting，字符串操作建议使用StringBuilder。 字符串显示使用String。

运行期间字符串连接计算利用StringBuilder的append完成。

案例：
	
	String s = "123";
	String ss = s + "abc";
	//ss = new StringBuilder(s)
	//		.append("abc").toString();

案例：

	String s = "123"+"456"+"abc";
	String ss = "123";
	String str = ss + "456"+"abc";
	//在一个表达式中出现连续的字符串连接，Java会
	//自动的优化为一个StringBuilder对象
	//String str = new StringBuilder(ss)
	//	.append("456").append("abc").toString();

> 在工作中一个表达式中的连续字符串连接不需要优化为StringBuilder

> 在反复进行字符串连接时候建议使用StringBuilder

## 正则表达式

用于声明字符串的规则表达式。

经常用于检测一个字符串是否符合特定规则。

语法：
1. 字符集合：
	


常见案例：

	邮政编码的规则 \d{6}
	身份证的规则 d{17}[\dXx]
	用户名的规则: 8到11个单词字符 \w{8,11}
	检查一个文件是否为jpeg照片文件： .+\\.jpe?g
	Excel能够支持的文件名规则 ： .+\.xls[xbm]?
	手机号的规则： (0086|\+86)?\s*1\d{10}








