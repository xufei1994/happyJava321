# 一.ServletConfig和ServletContext
## 1.context使用场景
- 大部分的查询都具备分页功能
- 分页需要一个参数:每页显示几条数据size
- 该参数一般可配置,由于被众多查询功能复用,使用context读取

## 2.context可以存取变量
![](1.png)

# 二.Servlet线程安全问题
![](2.png)
