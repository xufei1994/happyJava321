package autowire;

public class Foo {

	public Foo() {
		System.out.println("Foo()");
	}
	
}
