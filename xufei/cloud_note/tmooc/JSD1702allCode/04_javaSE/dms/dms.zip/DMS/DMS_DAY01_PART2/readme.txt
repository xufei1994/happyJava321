完成test包中所有测试用例方法，都测试成功后
将这些测试用例中的方法替换IOUtil中的同名方法

注:
test/resources包中的文件无需打开，这是配合测试用例使用的。

当全部完成后，运行DMSClient类，项目中应当
会出现两个文件:
1:last-position.txt，内容为:3720
2:log.txt,内容为10条日志信息

