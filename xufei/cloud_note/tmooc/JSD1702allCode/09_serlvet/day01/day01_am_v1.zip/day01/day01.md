# 一.WEB项目的演变
## 1.演变的规律
- 由单机向网络发展
- 由CS向BS发展

## 2.CS和BS的区别
### CS
- Client Server
- 客户端需要单独开发单独安装

### BS
- Browser Server
- 由浏览器充当客户端,不需要单独开发及安装

# 二.服务器如何给浏览器返回一个网页?
## 1.静态网页
- 开发手册网页,百科,小说,新闻
- 无论谁看结果都一样
- 服务器直接保存一份HTML,并向浏览器发送此HTML

## 2.动态网页
- 淘宝,微博
- 每个人看的结果有差异
- 服务器保存一个对象,由它动态拼一个网页,发送给浏览器
> 在Java中该对象是Servlet

## 3.Servlet的特征
- 是满足规范(sun)的对象,也叫组件
- 存储在服务器上
- 可以动态的拼资源(HTML,IMG). 术语:处理HTTP协议

## 4.什么是Servlet?
- 是sun推出的用来在服务器端处理HTTP协议的组件

# 三.服务器
## 1.名词解释
- Java服务器
- WEB服务器
- Java WEB服务器
- Servlet容器

## 2.本质
- 是一个软件
- 可以运行Java项目的软件

## 3.举例
- Tomcat(Apache)
- JBoss
- WebLogic
- WebSphere