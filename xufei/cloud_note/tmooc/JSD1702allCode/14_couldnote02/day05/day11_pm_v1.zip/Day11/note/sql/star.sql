select * from cn_note;

create table cn_star (
	cn_star_id varchar(50),
	cn_user_id varchar(50),
	cn_stars int,
	primary key(cn_star_id)
);

select cn_user_id from cn_user;

select * from cn_star;

select * from cn_note 
limit 0, 10;


select * from cn_note 
limit 10, 10;


select * from cn_note 
limit 20, 10;









