package day02;
/**
 * 输入一个IP地址，然后将4段数字分别输出
 * @author Xiloer
 *
 */
public class Test03 {

}
