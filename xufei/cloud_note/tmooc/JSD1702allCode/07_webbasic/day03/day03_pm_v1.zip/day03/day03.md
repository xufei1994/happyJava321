# 一.box
![](1.png)

# 二.选择器的优先级
- 元素选择器: 1
- 类选择器:   10
- ID选择器:   100
- .content>div : 10+1=11
- .data : 10
- .content>.data : 10+10=20