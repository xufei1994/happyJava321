package day12;
/**
 * 解析前需要修改pom.xml文档，加载dom4j的jar包。
 * 将emp.xml文件中的员工信息解析出来并以Emp实例保存到一个集合中然后
 * 按照工资从高到低的顺序输出每个员工信息
 * @author Xiloer
 *
 */
public class Test01 {

}
