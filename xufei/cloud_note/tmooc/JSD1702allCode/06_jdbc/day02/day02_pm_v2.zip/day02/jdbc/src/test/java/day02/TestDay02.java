package day02;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

import util.DBUtil;

public class TestDay02 {
	
	/**
	 * 测试DBUtil的方法
	 */
	@Test
	public void test1() {
		//假设浏览器传入的查询条件是
		int empno = 1;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			System.out.println(conn);
			Statement smt = conn.createStatement();
			String sql = 
				"select * from emps "
				+ "where empno>" + empno;
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				System.out.println(rs.getInt("empno"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}

	/**
	 * 如何使用PS执行DML
	 */
	@Test
	public void test2() {
		//假设页面传入的修改参数是:
		int empno = 1;
		String ename = "张三丰";
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = 
				"update emps set ename=? "
				+ "where empno=?";
			//创建ps对象,并让它立刻发送SQL
			PreparedStatement ps = 
				conn.prepareStatement(sql);
			//给参数?赋值
			//ps.set类型(?的序号,?的值)
			ps.setString(1, ename);
			ps.setInt(2, empno);
			//向数据库发送参数,并让数据库执行SQL
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}
	
	/**
	 * 如何使用PS执行DQL
	 */
	@Test
	public void test3() {
		//假设页面传入查询条件是
		double sal = 6000.0;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = 
				"select * from emps "
				+ "where sal>?";
			PreparedStatement ps = 
				conn.prepareStatement(sql);
			ps.setDouble(1, sal);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println(
					rs.getInt("empno"));
				System.out.println(
					rs.getString("ename"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}
	
	/**
	 * 使用PS执行查询语句,看它能否
	 * 避免注入攻击.
	 */
	@Test
	public void test4() {
		//假设页面传入的登录条件是:
		String username = "zhangsan";
		String password = "a' or 'b'='b";
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = 
				"select * from users "
				+ "where username=? "
				+ "and password=?";
			PreparedStatement ps = 
				conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("登录成功");
			} else {
				System.out.println("登录失败");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}
	
	/**
	 * ResultSetMetaData
	 */
	@Test
	public void test5() {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = 
				"select * from emps "
				+ "order by empno";
			Statement smt = conn.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			//获取结果集元数据
			ResultSetMetaData md = rs.getMetaData();
			//元数据中封装了结果集的描述信息
			System.out.println(md.getColumnCount());
			System.out.println(md.getColumnTypeName(2));
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}
	
}














