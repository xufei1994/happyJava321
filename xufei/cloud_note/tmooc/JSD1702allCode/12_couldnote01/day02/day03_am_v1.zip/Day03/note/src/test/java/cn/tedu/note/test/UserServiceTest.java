package cn.tedu.note.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.tedu.note.entity.User;
import cn.tedu.note.service.UserService;

public class UserServiceTest {
	
	ClassPathXmlApplicationContext ctx;
	
	@Before 
	public void initCtx(){
		ctx = new ClassPathXmlApplicationContext(
				"conf/spring-mvc.xml",
				"conf/spring-mybatis.xml",
				"conf/spring-service.xml");
	}
	@After
	public void close(){
		ctx.close();
	}

	@Test
	public void testLogin(){
		String name = "demo";
		String password = "123";
		UserService service = 
			ctx.getBean("userService",
			UserService.class);
		User user = service.login(
			name, password);
		System.out.println(user); 
	}
}




