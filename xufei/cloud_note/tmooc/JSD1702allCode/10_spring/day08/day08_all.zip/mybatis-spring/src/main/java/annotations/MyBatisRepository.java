package annotations;

public @interface MyBatisRepository {

}
