// scripts/note.js 编码一定是 utf-8

var SUCCESS = 0;
var ERROR = 1;

$(function(){
	
	//var userId = getCookie('userId');
	//console.log(userId);
	
	//网页加载以后, 立即读取笔记本列表
	loadNotebooks();
	
});

/** 加载笔记本列表数据 */
function loadNotebooks(){
	//利用ajax从服务器获取(get)数据, 使用getJSON方法
	var url = 'notebook/list.do';
	var data = {userId:getCookie('userId'),
			name:'demo'};
	$.getJSON(url, data, function(result){
		console.log(result);
		if(result.state==SUCCESS){
			var notebooks = result.data;
			//在showNotebooks方法中将全部的
			//笔记本数据 notebooks 显示到 
			// notebook-list 区域
			showNotebooks(notebooks);
		}else{
			alert(result.message);
		}
	});
}
/** 在notebook-list区域中显示笔记本列表 */
function showNotebooks(notebooks){
	//找显示笔记本列表的区域的ul元素
	//遍历notebooks数组, 将为每个对象创建一个li
	//元素, 添加到 ul元素中.
	var ul = $('#notebook-list ul');
	ul.empty();
	for(var i=0; i<notebooks.length; i++){
		var notebook = notebooks[i];
		var li = notebookTemplate.replace(
				'[name]', notebook.name);
		li = $(li);
		ul.append(li);
	}
}
var notebookTemplate = 
	'<li class="online">'+
	'<a><i class="fa fa-book" title="online" '+
	'rel="tooltip-bottom"></i> [name]</a>'+
	'</li>';










