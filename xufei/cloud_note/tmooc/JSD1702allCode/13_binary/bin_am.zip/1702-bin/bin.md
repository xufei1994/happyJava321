# 二进制


## 2进制在哪里?

计算机内部 **只有** 2进制数据!

	int i = 50;
	System.out.println(i);//"50"   Integer.toString(i)

Java编程语言, 编程语言利用算法支持10进制, 使用用户感受上可以使用10进制! 

> 编程语言: 人类与计算机沟通的桥梁!


显示2进制数据

	int i = 50;// Integer.parseInt();
	System.out.println(Integer.toBinaryString(i));

- Java 如何接收10进制数据:  Integer.parseInt();
	- 将10进制字符串转换为2进制int
- Java 如何输出10进制数据:  Integer.toString(); 
	- 将2进制int转换为10进制字符串

	Scanner in = new Scanner(System.in);
	int n = in.nextInt();// 底层调用了 Integer.parseInt();

## 什么是2进制

逢2进1的计数规则


## 16进制

16进制用于简写2进制

4位2进制可以简写为一位16进制数字

经典面试题:

	int i = 0x32; //0011 0010
	System.out.println(i);
	如上代码输出结果(  ) 
	答案: 50

	int i = 0xac;  
	System.out.println(i);
	如上代码输出结果(  ) 
	答案:  


## 补码

计算机处理 **有符号数(负数)** 问题的算法. 

补码算法: 4位数补码

规则:

1. 总的位数是4位数
2. 如果计算结果超过4位自动溢出舍弃



# 反射


