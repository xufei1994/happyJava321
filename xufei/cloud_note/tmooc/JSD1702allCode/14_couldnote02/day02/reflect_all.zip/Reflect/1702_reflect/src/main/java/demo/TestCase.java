package demo;

public class TestCase {
	
	public void testHello(){
		System.out.println("Hello");
	}
	
	private void testABC(){
		System.out.println("ABC");
	}
}

