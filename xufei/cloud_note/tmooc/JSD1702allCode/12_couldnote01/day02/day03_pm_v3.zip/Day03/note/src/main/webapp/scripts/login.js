/* scripts/login.js 编码为 utf-8  */

$(function(){
	//console.log('Hello World!');
	$('#login').click(loginAction);
});

function loginAction(){
	//console.log("loginAction");
	//获取用户输入的用户名和密码
	var name = $('#count').val();
	var password = $('#password').val();
	//data 对象中的属性名要与服务器控制器的参数
	// 名一致! login(name, password)
	var data = {"name":name, 
				"password":password};
	$.ajax({
		url:'user/login.do',
		data:data,
		type:'post',
		dataType:'json',
		success: function(result){
			console.log(result);
		},
		error: function(e){
			alert("通信失败!");
		}
	});
}








