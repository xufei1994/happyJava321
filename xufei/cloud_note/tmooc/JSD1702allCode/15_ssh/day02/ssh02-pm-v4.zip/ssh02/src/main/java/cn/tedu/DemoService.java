package cn.tedu;

public interface DemoService {
	void hello();
}
