package day07;
/**
 * 使用文件流复制myfile.txt文件为myfile_cp.txt
 * @author Xiloer
 *
 */
public class Test01 {

}
