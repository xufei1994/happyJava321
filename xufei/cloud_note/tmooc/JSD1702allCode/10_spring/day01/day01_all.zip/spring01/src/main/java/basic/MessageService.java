package basic;

public class MessageService {

	public MessageService() {
		System.out.println("MessageService()");
	}
	
	public void init(){
		System.out.println("init()");
	}
	
	public void destroy(){
		System.out.println("destroy()");
	}
	
}
