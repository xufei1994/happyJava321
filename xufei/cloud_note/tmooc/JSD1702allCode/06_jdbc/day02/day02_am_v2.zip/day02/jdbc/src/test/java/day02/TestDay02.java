package day02;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;

import util.DBUtil;

public class TestDay02 {
	
	/**
	 * 测试DBUtil的方法
	 */
	@Test
	public void test1() {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			System.out.println(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
	}

}














