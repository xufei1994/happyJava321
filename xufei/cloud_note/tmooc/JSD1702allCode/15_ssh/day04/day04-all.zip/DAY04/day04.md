#正课: 

hibernate简介/ID生成规则/对象生命周期管理/HQL查询/关系映射

#hibernate简介

##什么是? 冬眠

基于JDBC的,不用写SQL语句的持久层框架.其构想是java实体对象映射存储到数据库的表中,只需要维护对象与表的映射关系,hibernate自动生成SQL语句.

##为什么?

简化对数据库的操作.hibernate提供了不同数据库的统一接口,应用程序开发有了跨数据库的可能.

##核心的API

configuration sessionfactoty session query transaction

##工作原理

hibernate启动-->configuration(xml)-->sessionfactoty-->session

-->创建transaction-->持久化操作-->提交transaction-->关闭session

##处理流程

请求-->session中查-->sessionfactoty-->DB

##怎么使用?

步骤:

- 导包:hibernate核心包;数据库的驱动包

- 文件的配置:hibernate.cfg.xml(配置)/xxx.hbm.xml(映射)

- 调用hibernate的API对数据库进行操作

#ID生成规则(重点)

- 自增类型(mysql和sqlserver)

		create table student(id int not null auto_increment,name varchar(30),primary key(id))
		insert into student(id,name) values(null,"Tom");
		insert into student(name) values("Jack");
		映射文件的<id><generator class="identity">

- 序列(oracle和db2)
  
		<generator class="sequence">
		<param name="sequence">seq_name</param>
		</generator>

- UUID
		
		<generator class="uuid">

		create table teacher(id varchar(100) primary key,name varchar(30))

#hibernate对象生命周期管理(重点)

hibernate对象就是java中的实体对象.管理就是在实体对象的生命周期中被hibernate的操作.

- 临时状态:内存中有对象,DB中没有数据

- 持久状态:内存中有对象,DB中有数据,通过操作内存中的对象修改DB中的数据

- 游离状态:内存中有对象,DB中有数据,对象与数据断开了连接,修改对象不影响      

DB中的数据


#HQL查询

hibernate Query Language

面向对象的查询语言,语法类似SQL,但与数据库无关

SQL:select 字段 from 表

HQL:select 属性 from 类

##常用语法:

- from 类; 不支持"select*"

- select 属性 from 类

- where

- having 

- order by

- group by

##怎么使用?

- 获取session对象
- 编写HQL语句
- 创建查询对象Query
- 如果存在参数,调用setXXXX()赋值
- 调用Query的list()方法
- 关闭session对象

#作业

- 重写自增主键/uuid案例

- 重写hibernate对象三个状态切换的案例






























