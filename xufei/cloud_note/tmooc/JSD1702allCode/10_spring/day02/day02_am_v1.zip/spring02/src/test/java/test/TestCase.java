package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ioc.A;

public class TestCase {
	@Test
	public void test1(){
		String config = "ioc.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		A a = ac.getBean("a1",A.class);
		a.execute();
	}
}








