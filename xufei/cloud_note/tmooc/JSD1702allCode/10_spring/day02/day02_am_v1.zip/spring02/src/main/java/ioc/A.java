package ioc;

public class A {
	private B b;
	
	public void setB(B b) {
		System.out.println("setB()");
		this.b = b;
	}

	public A() {
		System.out.println("A()");
	}
	
	public void execute(){
		System.out.println("execute()");
		//调用B的f1()方法
		b.f1();
	}
}


