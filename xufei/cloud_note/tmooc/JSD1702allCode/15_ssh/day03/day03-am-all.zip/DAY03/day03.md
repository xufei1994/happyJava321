#Result常用类型
- dispatcher 转发
- redirectAction 重定向Action
- redirect 重定向URL
- Stream 用于图片的传输
- json Struts2-json-plugin

JSON两种使用方式:

- 发送Action中的全部属性
  <result type="json"></result>

- 发送Action中的某一个属性
  <result type="json">  
  <param name="root">属性名<param>
  </result>

#拦截器

##是什么?java动态拦截Action调用的对象

请求-->filter-拦截点->Action-拦截点->result-->浏览器

##为什么?适合封装通用的处理,便于复用,扩展

##怎么用?

- 创建拦截器
  需要实现interceptor接口

- 注册拦截器
  <pakage>下<interceptor name="aaa" class>

- 引用拦截器
  <action>下<interceptor-ref name="aaa" />

注意:在使用Struts过程中,一旦引用了自定义的拦截器.那么框架默认引用的拦截器栈就被撤消,导致一些框架功能不能正常实现.



















