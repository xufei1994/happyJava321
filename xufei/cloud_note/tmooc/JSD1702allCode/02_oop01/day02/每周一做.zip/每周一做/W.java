package day01;

import java.util.Arrays;
import java.util.Scanner;

public class W{
	public static void main(String[] args) {
		Scanner san = new Scanner(System.in);
		int n = san.nextInt();
		
		System.out.println(f(n));
		System.out.println(check(n));
	}
	public static int f(int n){
		if(n==1||n==2){
			return 1;
		}else{
			return f(n-1)+f(n-2);
		}
	}
	public static double check(int n) {
		return f(n-1)/(double)f(n);
	}
}

