package day09;
/**
 * 使用线程方式二创建两个线程:分别输出1000次，你好和再见
 * @author Xiloer
 *
 */
public class Test02 {

}
