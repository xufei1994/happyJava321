# 一.jQuery对象和DOM对象
## 1.通过$所获得的对象是jQuery对象
- $("p")
- $(img)
- $("<li></li>")

## 2.调用修改方法返回的是jQuery对象
- obj.width(218)
- obj.html("abc")

## 3.调用读取方法
### 1)若方法返回元素,则是jQuery对象
- obj.parent()
- obj.next()

### 2)若方法返回文本,则是DOM对象
- obj.html()
- obj.attr("src")