# 云笔记

## 登录(续)

### 显示错误消息

原理:

![](1.png)

1. 重构控制器增加异常处理方法 UserController

		@ExceptionHandler( UserNotFoundException.class)
		@ResponseBody
		public JsonResult handleUserNotFound(
				UserNotFoundException e){
			e.printStackTrace();
			return new JsonResult(2,e);
		}
		
		@ExceptionHandler(PasswordException.class)
		@ResponseBody
		public JsonResult handlePassword(
				PasswordException e){
			e.printStackTrace();
			return new JsonResult(3,e);
		}


2. 重构JsonResult 添加 构造器
	
		public JsonResult(int state, Throwable e) {
			this.state = state;
			this.message = e.getMessage();
		}

3. 重构 login.js 的loginAction方法, 显示错误信息

		var msg = result.message;
		if(result.state==2){
			$('#count').next().html(msg);
		}else if(result.state==3){
			$('#password').next().html(msg);
		}else{
			alert(msg);
		}

4. 测试

## 注册功能

原理:

![](2.png)

### 1. 持久层

1. 声明持久层方法: UserDao

		int addUser(User user);

2. 声明SQL UserMappeer.xml

		<insert id="addUser"
			parameterType="cn.tedu.note.entity.User">
			insert into cn_user (
				cn_user_id,
				cn_user_name,
				cn_user_password,
				cn_user_token,
				cn_user_nick
			) values (
				#{id},
				#{name},
				#{password},
				#{token},	
				#{nick}
			)
		</insert>

3. 测试 UserDaoTest:
	
		UserDao dao;
		@Before
		public void initDao(){
			dao = ctx.getBean(
					"userDao", UserDao.class);
		}
		@Test
		public void testAddUser(){
			String id=UUID.randomUUID().toString();
			String name = "Tom";
			String salt = "今天你吃了吗?";
			String password = 
				DigestUtils.md5Hex(salt+"123456");
			String token = "";
			String nick = "";
			User user = new User(
				id, name, password, token, nick);
			int n = dao.addUser(user);
			System.out.println(n); 
		}

### 2. 业务层

1. 声明业务层方法 UserService

		/**
		 * UserService 中添加注册功能
		 * @param name 
		 * @param nick
		 * @param password
		 * @param confirm
		 * @return 注册成功的用户信息
		 * @throws UserNameException 用户名异常
		 * @throws PasswordException 密码异常
		 */
		User regist(String name, String nick, 
				String password, String confirm)
			throws UserNameException, 
			PasswordException;

2. 声明业务层异常 UserNameException
		
		public class UserNameException extends RuntimeException {
			private static final long serialVersionUID = 6435296194529486206L;
		
			public UserNameException() {
			}
		
			public UserNameException(String message) {
				super(message);
			}
		
			public UserNameException(Throwable cause) {
				super(cause);
			}
		
			public UserNameException(String message, Throwable cause) {
				super(message, cause);
			}
		
			public UserNameException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
				super(message, cause, enableSuppression, writableStackTrace);
			}
		
		}

3. 重构 jdbc.properties 和 UserServiceImpl, 将salt存储到配置文件, 利用Spring注入到属性中:
	
		# jdbc.properties
		salt=\u4ECA\u5929\u4F60\u5403\u4E86\u5417?

		//	UserServiceImpl
		@Value("#{jdbc.salt}")
		private String salt;

4. 实现业务层方法: UserServiceImpl

		public User regist(String name, 
				String nick, String password, 
				String confirm)
				throws UserNameException, PasswordException {
			//检查name, 不能重复
			if(name==null || name.trim().isEmpty()){
				throw new UserNameException("不能空");
			}
			User one = userDao.findUserByName(name);
			if(one!=null){
				throw new UserNameException("已注册");
			}
			//检查密码
			if(password==null || password.trim().isEmpty()){
				throw new PasswordException("不能空");
			}
			if(! password.equals(confirm)){
				throw new PasswordException("确认密码不一致");
			}
			//检查nick
			if(nick ==null || nick.trim().isEmpty()){
				nick = name;
			}
			String id = UUID.randomUUID().toString();
			String token = "";
	 
			password = DigestUtils.md5Hex(salt+password);
			User user = new User(
					id, name, password, 
					token, nick);
			int n = userDao.addUser(user);
			if(n!=1){
				throw new RuntimeException("添加失败!");
			}
			return user;
		}

5. 测试:UserServiceTest

		UserService service;
		@Before
		public void initService(){
			service = ctx.getBean("userService",
					UserService.class);
		}
		
		@Test
		public void testRegist(){
			User user = service.regist(
					"Andy", "Andy", "123456", 
					"123456");
			System.out.println(user); 
		}
		
### 3. 控制器 

1. 添加控制器方法 UserController

		@RequestMapping("/regist.do")
		@ResponseBody
		public JsonResult regist(String name,
				String nick, String password,
				String confirm){
			User user = userService.regist(
					name, nick, password, confirm);
			return new JsonResult(user);
		}

2. 测试

		http://localhost:8080/note/user/regist.do?name=Jerry&nick=AN&password=12345&confirm=12345


### 4. 添加注册JS脚本



	