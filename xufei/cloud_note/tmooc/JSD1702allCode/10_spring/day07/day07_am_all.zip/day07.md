# 1. SpringJdbc
## (1)SpringJdbc是什么?
	Spring框架对jdbc的封装。
## (2)编程步骤
	step1.导包
		spring-webmvc,spring-jdbc,
		ojdbc,dbcp,junit。
	step2.添加spring配置文件。
	step3.配置JdbcTemplate。	
		注：JdbcTemplate把一些重复性的代码（比如获取连接，关闭）		连接，异常处理等等都写好了），我们只需要调用该对象的
			方法就可以很方便的访问数据库。
![](a1.png)

	step4.调用JdbcTemplate的方法来访问数据库。
		注：通常将JdbcTemplate注入到DAO。
![](a2.png)

	create table t_emp(
		id number(8) primary key,
		name varchar2(20),
		age number(3)
	);
	create sequence t_emp_seq;

	
	

	
	
	