package day02;
/**
 * 设计Excel能够支持的文件名规则 
 *  abc.xlsx
 *  abc.xls
 *  abd.xlsb
 *  def.xlsm
 *  
 *  .+\.xls[xbm]?
 */
public class Demo06 {
	public static void main(String[] args) {
		//自行测试...
	}
}
