package dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import entity.Employee;

@Repository("employeeDAO")
public class EmployeeDAO {
	
	@Autowired
	@Qualifier("jt")  
	private JdbcTemplate jt;
	
	public void save(Employee e){
		String sql = 
				"INSERT INTO t_emp "
			+ "VALUES(t_emp_seq.nextval,?,?)";
		Object[] args = 
			{e.getName(),e.getAge()};
		jt.update(sql, args);
	}
}



