package day02;
/**
 * 将字符串"123abc456def789ghi"中的英文部分替换为"#char#"
 * @author Xiloer
 *
 */
public class Test04 {

}
