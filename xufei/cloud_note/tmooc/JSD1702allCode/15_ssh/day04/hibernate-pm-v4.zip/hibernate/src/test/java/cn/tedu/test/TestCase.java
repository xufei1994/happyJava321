package cn.tedu.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import cn.tedu.Student;
import cn.tedu.Teacher;
import cn.tedu.User;

public class TestCase {
	public static Session openSession(){
		//读取数据库配置信息
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//获取session对象
		SessionFactory factory
				=cfg.buildSessionFactory();
		Session session=factory.openSession();
		return session;
	}
	//@Test
	public void testUser(){
		//读取配置文件
		Configuration cfg
			=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//获取session对象
		SessionFactory factory
			=cfg.buildSessionFactory();
		Session session=factory.openSession();
		//通过session操作数据库
		User u
			=(User) session.get(User.class, 1);
		System.out.println(u);
		session.close();
	}
	//@Test
	public void testStudent(){
		//读取数据库配置信息
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//获取session对象
		SessionFactory factory
					=cfg.buildSessionFactory();
		Session session=factory.openSession();
		//创建事务
		Transaction t=session.beginTransaction();
		t.begin();
		//创建student对象,给name属性赋值
		Student stu=new Student();
		stu.setName("Alice");
		System.out.println(stu);
		session.save(stu);
		System.out.println(stu);
		t.commit();
		//session.save(对象)
		session.close();
	}
	//配置映射文件 Teacher.hbm.xml
	//插入一条数据到表中
	//@Test
	public void testTeacher(){
		//读取数据库配置信息
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//获取session对象
		SessionFactory factory
				=cfg.buildSessionFactory();
		Session session=factory.openSession();
		//创建事务
		Transaction t=session.beginTransaction();
		t.begin();
		//创建student对象,给name属性赋值
		Teacher stu=new Teacher();
		stu.setName("Alice");
		System.out.println(stu);
		session.save(stu);
		System.out.println(stu);
		t.commit();
		//session.save(对象)
		session.close();
	}
	//@Test
	public void testUpdate(){
		//读取数据库配置信息
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		//获取session对象
		SessionFactory factory
				=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		t.begin();
		Student stu
				=(Student) session.get(Student.class, 1);
		System.out.println(stu);
		stu.setName("Peter");
		System.out.println(stu);
		t.commit();
	    session.close();
	}
	@Test
	public void testDelete(){
		Session s=openSession();
		Transaction t=s.beginTransaction();
		t.begin();
		Student stu
				=(Student) s.get(Student.class, 1);
		System.out.println(stu);
		s.delete(stu);
		t.commit();
		s.close();
	}
}







