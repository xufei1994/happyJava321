package cn.tedu.shoot;
/** 子弹: 是飞行物 */
public class Bullet extends FlyingObject {
	private int speed = 3; //移动的速度
	/** 构造方法 */
	public Bullet(){
		
	}
}











