#关联关系

数据库中以主外键的形式体现;实体对象中体现在对象与对象的引用.

		User{
		id
		name
		set<Book> books=new HashSet<Book>()   <one-to-many>
		}

		Book{
		id
		name
		User user <many-to-one>
		}

表user(id,name)

表book(id,name,userid)

		create table t_user(u_id int not null auto_increment,u_name varchar(30),primary key(u_id))

		create table t_book(b_id int not null auto_increment,b_name varchar(30),u_userid int,primary key(b_id))

		insert into t_user(u_name) values("Robin")
		insert into t_user(u_name) values("Jack")
		insert into t_user(u_name) values("Andy")

		insert into t_book(b_name,u_userid) values("Oralce",1);
		insert into t_book(b_name,u_userid) values("Spring",1);
		insert into t_book(b_name,u_userid) values("Struts",1);
		insert into t_book(b_name,u_userid) values("Mybatis",1)

案例:

1. 创建实体类TUser/TBook

2. 配置映射文件TUser.hbm.xml/TBook.hbm.xml(重点)

3. 实现测试方法:查询id=1的用户数据

#hibernate的缓存机制

##为什么?

hibernate是持久层的框架,与数据库交互

为了降低应用程序与物理数据源的交互频率,提高应用的运行性能

##工作原理

查询请求首先进入一级缓存,如果没有,进入到二级缓存查找,还没有,与数据库进行交互,将查询到的结果返回给应用程序.

##一级缓存的管理

- evict(Object):将对象从session中清楚掉,从持久状态进入到游离状态

- clear():将session中的所有对象都清除掉

- flush():将缓存中的数据与数据库中的数据进行同步

- contains(Object):判断缓存中是否存在已知的对象

##一级缓存的应用

- save():将保存的数据放到session

- get():将查询的数据放到session

- load():将查询的数据放到session

- HQL查询:将查询的数据放到session

案例步骤:

1. get()获取一定数据

2. 转换成对象1

3. 重复第一个步骤

4. 转换成对象2

5. 对象1==对象2

#懒惰加载 lazy

##什么是?

懒惰=延迟  尽可能晚的将数据库的数据加载到内存中来

##为什么?

提高应用的运行性能

		user{
		id
		name
		books
		}

##延迟加载应用

- session.load()

- query.iterate()

- 关联映射的查询

##OpenSessionInViewFilter


#SSH整合

##hibernate+spring 

spring管理session和sessionFactory

步骤:

- 导包: hibernate-core;mysql-conn;spring-orm;c3p0

- 配置文件:spring-context.xml;xxx.hbm.xml

案例:登录

create table cn_user(id varchar(100),name varchar(30),password varchar(30),token varchar(100),nick varchar(30),primary key(id))

insert into cn_user values('1','JackSon','123456','123456','Jack')

步骤:

1. 创建User实体类

2. 配置User.hbm.xml

3. 创建UserDao接口,定义抽象方法

4. 创建UserDao接口的实现类

5. 测试Dao

6. Service的实现

7. 测试Service

8. 实现Action组件

9. 测试Acation


##struts2+hibernate+spring 

- 导包:struts2-core 

- 配置文件: web.xml









