package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import basic.Teacher;

public class TestCase {
	@Test
	public void test1(){
		String config = "basic.xml";
		//启动spring容器
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(
				config);
		//通过容器获得bean
		Teacher t1 = 
				ac.getBean("t1",Teacher.class);
		Teacher t2 =
				ac.getBean("t1",Teacher.class);
		System.out.println(t1 == t2);
	}
}





