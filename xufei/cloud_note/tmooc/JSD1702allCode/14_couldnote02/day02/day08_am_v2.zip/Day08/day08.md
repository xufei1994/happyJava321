# 云笔记

## 回收站

### 1. 显示回收站

原理:

![](trash-bin.png)

1. 重构 edit.html 为回收站和回收站按钮设置ID

	> 重构 118 行, 设置 id='trash-bin'

		<div class="col-xs-3" style='padding:0;display:none;' id='trash-bin'>

	> 重构 81 行, 设置 id='trash_button'

		<div class="col-xs-4 click" id='trash_button' title='回收站'><i class='fa fa-trash-o' style='font-size:20px;line-height:31px;'></i></div>

2. 在ready方法中绑定按钮事件:

		//监听回收站按钮被点击
		$('#trash_button').click(showTrashBin);

	> 添加事件处理方法:

		/** 监听回收站按钮被点击 */
		function showTrashBin(){
			$('#trash-bin').show() ;
			$('#note-list').hide() ;
			//loadTrashBin(); 加载删除笔记列表
		}

### 2. 持久层

1. 添加数据访问方法 NoteDao

		List<Map<String, Object>> findDeleteNotesByUserId(String userId);

2. 添加SQL NoteMapper.xml

		<select id="findDeleteNotesByUserId"
			parameterType="string"
			resultType="map">
			select 
				cn_note_id as id,
				cn_note_title as title 
			from 
				cn_note
			where
				cn_user_id = #{userId} and 
				cn_note_status_id = '0'
			order by
				cn_note_last_modify_time desc
		</select>

3. 测试 

		...

### 3. 业务层

1. 添加业务层方法 NoteService

	List<Map<String, Object>> listNotesInTrashBin(String userId)
			throws UserNotFoundException;

1. 实现业务层方法 NoteServiceImpl

		public List<Map<String, Object>> listNotesInTrashBin(
				String userId) throws UserNotFoundException {
			if(userId==null||userId.trim().isEmpty()){
				throw new UserNotFoundException("ID空");
			}
			User user=userDao.findUserById(userId);
			if(user==null){
				throw new UserNotFoundException("木有人");
			}
			return noteDao.findDeleteNotesByUserId(userId);
		}

3. 测试

		...

### 4. 表现层

1. 添加 loadTrashBin 方法利用Ajax加载回收站笔记列表: 
		
		/** 加载回收站中的笔记列表 */
		function loadTrashBin(){
			var url = 'note/trash.do';
			var data = {userId: getCookie('userId')};
			$.getJSON(url, data, function(result){
				if(result.state==SUCCESS){
					showNotesInTrashBin(result.data);
				}else{
					alert(result.message);
				}
			});
		}

2. 添加显示笔记列表到回收站方法 showNotesInTrashBin

		function showNotesInTrashBin(notes){
			var ul = $('#trash-bin ul');
			ul.empty();
			for(var i=0; i<notes.length; i++){
				var note = notes[i];
				var li = trashBinItem.replace('[title]', note.title);
				li = $(li);
				li.data('noteId', note.id);
				ul.append(li);
			}
		}
		
		var trashBinItem = 
			'<li class="disable">'+
				'<a><i class="fa fa-file-text-o" title="online" rel="tooltip-bottom"></i>'+
				' [title]'+
				'<button type="button" class="btn btn-default btn-xs btn_position btn_delete">'+
					'<i class="fa fa-times"></i>'+
				'</button>'+
				'<button type="button" class="btn btn-default btn-xs btn_position_2 btn_replay">'+
					'<i class="fa fa-reply"></i>'+
				'</button></a>'+
			'</li>';
	
	> 其中 trashBinItem 是回收站笔记项目的模板

3. 重构 showTrashBin 方法, 在显示回收站后加载以删除笔记列表

		/** 监听回收站按钮被点击 */
		function showTrashBin(){
			$('#trash-bin').show() ;
			$('#note-list').hide() ;
			loadTrashBin();// 加载已删除笔记列表
		}

4. 测试

		...