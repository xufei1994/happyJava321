package day04;

import java.util.Collection;
import java.util.ArrayList;
/**
 * 集合的add方法 
 */
public class Demo01 {
	public static void main(String[] args) {
		Collection col=new ArrayList();
		col.add("Tom");
		col.add("Jerry");
		System.out.println(col); 
	}
}



