# 云笔记

## 回收站

### 1. 显示回收站

1. 重构 edit.html 为回收站和回收站按钮设置ID

	> 重构 118 行, 设置 id='trash-bin'

		<div class="col-xs-3" style='padding:0;display:none;' id='trash-bin'>

	> 重构 81 行, 设置 id='trash_button'

		<div class="col-xs-4 click" id='trash_button' title='回收站'><i class='fa fa-trash-o' style='font-size:20px;line-height:31px;'></i></div>

2. 在ready方法中绑定按钮事件:

		//监听回收站按钮被点击
		$('#trash_button').click(showTrashBin);

	> 添加事件处理方法:

		/** 监听回收站按钮被点击 */
		function showTrashBin(){
			$('#trash-bin').show() ;
			$('#note-list').hide() ;
			//loadTrashBin(); 加载删除笔记列表
		}
