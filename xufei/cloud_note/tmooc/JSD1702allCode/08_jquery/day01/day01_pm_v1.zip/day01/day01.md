# jQuery对象
![](1.png)