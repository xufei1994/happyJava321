package day01;
/**
 * 测试indexOf重载的方法 
 */
public class Demo07 {
	public static void main(String[] args) {
		String url = "http://tedu.cn/index.html";
		//从字符串位置7开始查找 "/"
		int i = url.indexOf("/",7);
		System.out.println(i);//14
		
		//lastIndexOf
	}
}






