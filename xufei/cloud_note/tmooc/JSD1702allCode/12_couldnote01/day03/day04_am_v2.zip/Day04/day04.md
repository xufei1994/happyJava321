# 云笔记

## 登录(续)

### 显示错误消息

原理:

![](1.png)

1. 重构控制器增加异常处理方法 UserController

		@ExceptionHandler( UserNotFoundException.class)
		@ResponseBody
		public JsonResult handleUserNotFound(
				UserNotFoundException e){
			e.printStackTrace();
			return new JsonResult(2,e);
		}
		
		@ExceptionHandler(PasswordException.class)
		@ResponseBody
		public JsonResult handlePassword(
				PasswordException e){
			e.printStackTrace();
			return new JsonResult(3,e);
		}


2. 重构JsonResult 添加 构造器
	
		public JsonResult(int state, Throwable e) {
			this.state = state;
			this.message = e.getMessage();
		}

3. 重构 login.js 的loginAction方法, 显示错误信息

		var msg = result.message;
		if(result.state==2){
			$('#count').next().html(msg);
		}else if(result.state==3){
			$('#password').next().html(msg);
		}else{
			alert(msg);
		}

4. 测试


## 注册功能







