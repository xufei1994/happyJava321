package day07;
/**
 * 使用字符流复制当前程序的源文件到当前项目根目录下。
 * @author Xiloer
 *
 */
public class Test05 {

}
