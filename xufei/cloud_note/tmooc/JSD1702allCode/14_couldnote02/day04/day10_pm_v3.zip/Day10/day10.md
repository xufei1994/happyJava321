# 云笔记

## Spring 事务管理

### 只读属性

对于单纯读取数据库操作, 可以设置readOnly=true, 可以提高数据的放效率.

	@Transactional(readOnly=true)
	public List<Map<String, Object>> listNotesInTrashBin(
			String userId) throws UserNotFoundException {

### 事务的传播

业务过程重构时候需要业务方法调用业务方法, 这样就需要一个业务方法的事务传播到另外一个业务方法中, 整合为一个事务.

案例: 

![](1.png)


步骤:

1. 创建数据表:
		
		create table cn_star (
			cn_star_id varchar(50),
			cn_user_id varchar(50),
			cn_stars int,
			primary key(cn_star_id)
		);
			
2. 声明 StarsDao

		public interface StarsDao {
			Stars findStarsByUserId(String userId);
			
			int insertStars(Stars stars);
			
			int updateStars(Stars stars);
		}

3. 声明SQL StarsMapper.xml

		<mapper namespace="cn.tedu.note.dao.StarsDao">
			
		 	<select id="findStarsByUserId"
		 		parameterType="string"
		 		resultType="cn.tedu.note.entity.Stars">
		 		select 
		 			cn_star_id as id,
		 			cn_user_id as userId,
		 			cn_stars as stars	
		 		from
		 			cn_star
		 		where 
		 			cn_user_id = #{userId}
		 	</select>
			<insert id="insertStars"
				parameterType="cn.tedu.note.entity.Stars">
				insert into cn_star(
					cn_star_id,
					cn_user_id,
					cn_stars
				)values(
					#{id},
					#{userId},
					#{stars}
				)
			</insert>
			<update id="updateStars"
				parameterType="cn.tedu.note.entity.Stars">
				update cn_star
				set
					cn_stars = #{stars}
				where 
					cn_user_id=#{userId} or
					cn_star_id=#{id}
			</update>
		</mapper>

4. 声明业务层接口方法 NoteService

		boolean addStars(String userId, int stars)
			throws UserNotFoundException;

5. 实现方法 NoteServiceImpl

		@Transactional
		public boolean addStars(String userId, int stars) 
				throws UserNotFoundException {
			if(userId==null||userId.trim().isEmpty()){
				throw new UserNotFoundException("ID空");
			}
			User user=userDao.findUserById(userId);
			if(user==null){
				throw new UserNotFoundException("木有人");
			}
			//检查是否已经有星了
			Stars st=starsDao.findStarsByUserId(userId);
			if(st==null){//如果没有星星
				String id = UUID.randomUUID().toString();
				st = new Stars(id, userId, stars);
				int n = starsDao.insertStars(st);
				if(n!=1){
					throw new RuntimeException("失败");
				}
			}else{//如果有星星,就在现有星星数量上增加
				int n = st.getStars()+stars;
				if(n<0){
					// n = 0; 
					throw new RuntimeException("扣分太多!");
				}
				st.setStars(n);
				n = starsDao.updateStars(st);
				if(n!=1){
					throw new RuntimeException("失败");
				}
			}
			return true;
		}	
		
6. 测试: NoteServiceTest

		@Test
		public void testAddStars(){
			String userId="03590914-a934-4da9-ba4d-b41799f917d1";
			boolean b = service.addStars(userId, 5);
			System.out.println(b);
			b = service.addStars(userId, 6);
			System.out.println(b);
		}

7. 重构 addNote方法, 实现添加笔记时候送星星功能, 进而实现事务的传播:
	
		@Transactional
		public Note addNote(String userId, 
				String notebookId, String title)
				throws UserNotFoundException, 
				NotebookNotFoundException {
		
			if(userId==null||userId.trim().isEmpty()){
				throw new UserNotFoundException("ID空");
			}
			User user=userDao.findUserById(userId);
			if(user==null){
				throw new UserNotFoundException("木有人");
			}
			if(notebookId==null||notebookId.trim().isEmpty()){
				throw new NotebookNotFoundException("ID空");
			}
			int n=notebookDao.countNotebookById(notebookId);
			if(n!=1){
				throw new NotebookNotFoundException("没有笔记本");
			}
			if(title==null || title.trim().isEmpty()){
				title="葵花宝典";
			}
			String id = UUID.randomUUID().toString();
			String statusId = "1";
			String typeId = "1";
			String body = "";
			long time=System.currentTimeMillis();
			Note note = new Note(id, notebookId,
				userId, statusId, typeId, title, 
				body, time, time);
			n = noteDao.addNote(note);
			if(n!=1){
				throw new NoteNotFoundException("保存失败");
			}
			//当前的事务, 会传播到 addStart方法中
			//整合为一个事务!
			addStars(userId, 5);
			
			return note;
		} 

8. 测试...



### 事务传播(propagation)属性

重点掌握 Propagation.REQUIRED

1. @Transactional(propagation=Propagation.REQUIRED)
	- 需要事务, 如果没有事务创建新事务, 如果当前有事务参与当前事务
2. @Transactional(propagation=Propagation.MANDATORY)
	- 必须有事务, 如果当前没有事务就抛异常
3. @Transactional(propagation=Propagation.NEVER)
	- 绝不, 绝对不能有事务, 如果在事务中调用则抛出异常
4. @Transactional(propagation=Propagation.NESTED)
	- 嵌套, 必须被嵌套到其他事务中
5. @Transactional(propagation=Propagation.NOT_SUPPORTED)
	- 不支持事务
6. @Transactional(propagation=Propagation.SUPPORTS)
	- 支持事务, 如果没有事务也不会创建新事务
7. @Transactional(propagation=Propagation.REQUIRES_NEW)
	- 必须是新事务, 如果有当前事务, 挂起当前事务并且开启新事务.

### 事务隔离属性

一共有4种, 一般采用 @Transactional(isolation=Isolation.READ_COMMITTED) 级别, 是并发性能和安全性折中的选择. 是大多数软件项目采用的隔离级别.

### 声明式事务

就是所有业务方法使用@Transactional, 如果是只读方法, 建议增加readOnly=true 

面试题目:

	Spring 声明式事务是如何实现的?
	答案: 利用AOP技术实现.

## 文件的上载与下载

### HTTP协议中文件是如何下载的

[http://doc.tedu.cn/rfc/rfc2616.txt](http://doc.tedu.cn/rfc/rfc2616.txt "HTTP 1.1 协议参考")

根据HTTP1.1协议, 知道服务器向客户端传输数据如下:
	
	HTTP/1.1 200 OK
	Content-Type: image/png
	Content-Length: 130
	
	数据内容

安装这个规则, 可以利用Servlet向客户端发送自定义图片:

1. 声明Servlet
		
		public class ImageServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			protected void doGet(
					HttpServletRequest request, 
					HttpServletResponse response) 
					throws ServletException, IOException {
				//发送照片
				byte[] png = createPng();
				response.setContentType("image/png"); 
				response.setContentLength(png.length);
				//在消息body中发送消息数据
				response.getOutputStream().write(png);
			}
			/**
			 * 创建一个图片, 并且编码为 png 格式, 返回
			 * 编码以后的数据 
			 */
			private byte[] createPng() throws IOException{ 
				BufferedImage img = 
					new BufferedImage(200, 80, 
					BufferedImage.TYPE_3BYTE_BGR);
				//在图片上绘制内容
				img.setRGB(100, 40, 0xffffff);
				//将图片编码为PNG
				ByteArrayOutputStream out = 
						new ByteArrayOutputStream();
				ImageIO.write(img, "png", out);
				out.close();
				byte[] png = out.toByteArray();
				return png;
			}
		}
		
2. 配置Servlet 
	
		  <servlet>
		    <description></description>
		    <display-name>ImageServlet</display-name>
		    <servlet-name>ImageServlet</servlet-name>
		    <servlet-class>cn.tedu.note.web.ImageServlet</servlet-class>
		  </servlet>
		  <servlet-mapping>
		    <servlet-name>ImageServlet</servlet-name>
		    <url-pattern>/demoimg</url-pattern>
		  </servlet-mapping>

3. 测试

		http://localhost:8080/note/demoimg

	> 显示生产的图片






	