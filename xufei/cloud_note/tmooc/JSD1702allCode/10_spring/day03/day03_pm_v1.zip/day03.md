## (7)spring表达式
	注：读取bean的属性
![](el.png)

# 1. 使用注解来简化配置文件
## (1)什么是组件扫描?
	容器会扫描指定的包及其子包下面的所有的
	类，如果该类前面有特定的注解比如@Component）,
	则容器会将其纳入容器进行管理（相当于在配置文件里面
	有一个bean元素）。
## (2)如何进行组件扫描?
	step1. 在类前面添加特定的注解，比如 @Component
	注：默认的id是首字母小写之后的类名。
![](z0.png)
![](z2.png)

	step2. 在配置文件当中，配置组件扫描。
![](z1.png)
## (3)依赖注入相关的注解
	1)@Autowired @Qualifier
	注：该注解支持set方法和构造器注入。
![](a1.png)
![](a2.png)

	2)@Resource
	注：该注解只支持set方法注入。
![](a3.png)
![](a4.png)

## (4)注入基本类型的值和spring表达式的值
![](value.png)


# SpringMVC
## (1)什么是SpringMVC?
	用来简化基于MVC架构的web应用程序开发的框架。
	注：SpringMVC是spring中的一个模块。

	