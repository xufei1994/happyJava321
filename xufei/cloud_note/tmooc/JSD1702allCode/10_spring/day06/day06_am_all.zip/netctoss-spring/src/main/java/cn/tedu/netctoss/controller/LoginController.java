package cn.tedu.netctoss.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.tedu.netctoss.entity.Admin;
import cn.tedu.netctoss.service.ApplicationException;
import cn.tedu.netctoss.service.LoginService;

@Controller
public class LoginController {
	
	@Resource(name="loginService")
	private LoginService loginService;
	
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		System.out.println("toLogin()");
		return "login";
	}
	
	@RequestMapping("/login.do")
	public String login(
			HttpServletRequest request,
			HttpSession session){
		System.out.println("login()");
		//读取帐号，密码
		String adminCode = 
				request.getParameter(
						"adminCode");
		System.out.println("adminCode:"
						+ adminCode);
		String pwd = 
				request.getParameter("pwd");
		//调用业务层提供的服务
		
		try{
			Admin admin = 
				loginService.checkLogin(
						adminCode, pwd);
			//登录成功，将一些数据绑订到
			//session对象上。
			session.setAttribute("admin",
					admin);
		}catch(Exception e){
			e.printStackTrace();
			if(e instanceof ApplicationException){
				//应用异常，明确提示用户
				/*
				 * getMessage方法继承自
				 * RuntimeException，作用是
				 * 获得异常的描述信息。
				 */
				request.setAttribute(
						"login_failed", 
						e.getMessage());
				return "login";
			}
			//系统异常,提示用户稍后重试
			return "error";			
		}
		
		
		return "redirect:toIndex.do";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex(){
		System.out.println("toIndex()");
		return "index";
	}
}




