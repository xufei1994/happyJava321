package cn.tedu.service;

import cn.tedu.Result;

public interface UserService {
	 Result login(String name,String password);
}
