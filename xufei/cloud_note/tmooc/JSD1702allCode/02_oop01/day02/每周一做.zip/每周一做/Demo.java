package AA;

public class Demo {

	public static void main(String[] args) {
		int[] ary = { 1,2,3,4,5,6,7,8,9 };
		int[] c = remove(ary,1);
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]);
		}
	}
	public static int[] remove(int[] ary, int index) {
		int[] a = new int[ary.length - 1];
		int j = 0;
		for (int i = 0; i < ary.length; i++) {
			if (i!= index) {
				a[j] = ary[i];
				j++;
			}
		}
		return a;
	}
}
