#正课: 

hibernate简介/ID生成规则/对象生命周期管理/HQL查询/关系映射

#hibernate简介

##什么是? 冬眠

基于JDBC的,不用写SQL语句的持久层框架.其构想是java实体对象映射存储到数据库的表中,只需要维护对象与表的映射关系,hibernate自动生成SQL语句.

#为什么?
简化对数据库的操作.hibernate提供了不同数据库的统一接口,应用程序开发有了跨数据库的可能.

#核心的API

configuration sessionfactoty session query transaction

#工作原理

hibernate启动-->configuration(xml)-->sessionfactoty-->session

-->创建transaction-->持久化操作-->提交transaction-->关闭session

#处理流程

请求-->session中查-->sessionfactoty-->DB



