# 自我介绍
- 李洪鹤
- lihh@tedu.cn

# 一.Java体系结构
![](1.png)

# 二.JDBC简介
## 1.JDBC的要素
![](2.png)

## 2.JDBC的使用步骤
![](3.png)

## 3.管理连接
![](4.png)

# 补充:maven
## 1.maven的使用方式
- 参考: http://doc.tedu.cn/maven/index.html

## 2.导包失败怎么办?
- 将pom.xml中的代码(<dependency>)删除
- 将下载失败的缓存文件删除(/.m2/repository下)
> 看Eclipse左侧的路径