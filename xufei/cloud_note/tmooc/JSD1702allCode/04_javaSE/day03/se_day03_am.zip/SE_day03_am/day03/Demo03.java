package day03;
/**
 * 包装类型 
 */
public class Demo03 {
	public static void main(String[] args) {
		Integer i = new Integer(5);
		Integer j = Integer.valueOf(5);
		Integer k = 5;//Java 5 自动包装功能
		
		System.out.println(k);//5
		System.out.println(i);//5
		System.out.println(j);//5
		
		
		
		
	}
}
