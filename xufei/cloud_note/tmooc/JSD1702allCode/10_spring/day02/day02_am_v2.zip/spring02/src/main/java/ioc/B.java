package ioc;

public class B implements IB{

	public B() {
		System.out.println("B()");
	}
	
	public void f1(){
		System.out.println("f1()");
	}
	
}
