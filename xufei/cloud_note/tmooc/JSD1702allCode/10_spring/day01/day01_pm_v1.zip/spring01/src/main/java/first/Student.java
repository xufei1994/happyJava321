package first;

public class Student {
	public Student(){
		System.out.println("Student()");
	}
}
