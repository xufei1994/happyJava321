# 自我介绍
- 李洪鹤
- lihh@tedu.cn

# 一.Java体系结构
![](1.png)

# 二.JDBC简介
## 1.JDBC的要素
![](2.png)

## 2.JDBC的使用步骤
![](3.png)