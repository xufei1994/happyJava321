# 补充1:W3C中文官方手册
- 外网:www.w3school.com.cn
- 内网:doc.tedu.cn
> 内网上的文档可以从canglaoshi.org网站下载