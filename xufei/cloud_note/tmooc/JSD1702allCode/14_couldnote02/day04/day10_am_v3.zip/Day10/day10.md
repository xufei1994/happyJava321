# 云笔记

## Spring 事务管理

### 只读属性

对于单纯读取数据库操作, 可以设置readOnly=true, 可以提高数据的放效率.

	@Transactional(readOnly=true)
	public List<Map<String, Object>> listNotesInTrashBin(
			String userId) throws UserNotFoundException {

### 事务的传播

