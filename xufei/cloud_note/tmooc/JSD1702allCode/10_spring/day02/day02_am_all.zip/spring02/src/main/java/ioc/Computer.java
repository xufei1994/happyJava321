package ioc;

public class Computer {

	public Computer() {
		System.out.println("Computer()");
	}
	
}
