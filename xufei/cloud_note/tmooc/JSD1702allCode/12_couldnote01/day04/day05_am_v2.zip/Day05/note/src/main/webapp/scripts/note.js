// scripts/note.js 编码一定是 utf-8

var SUCCESS = 0;
var ERROR = 1;

$(function(){
	
	var userId = getCookie('userId');
	console.log(userId);
	
});