package demo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

/**
 * 反射API 
 */
public class Demo01 {
	public static void main(String[] args) 
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		//动态加载类
		Scanner in = new Scanner(System.in);
		System.out.print("输入类名:");
		//动态获得类名
		String className = in.nextLine();
		Class cls = Class.forName(className);
		System.out.println(cls);
		//输出加载以后的类的名字
		System.out.println(cls.getName());
		
		//动态创建对象
		Object obj=cls.newInstance();
		System.out.println(obj);
		
		//动态检查类中声明的方法信息
		Method[] methods = 
				cls.getDeclaredMethods(); 
		for(Method m:methods){
			System.out.println(m);//输出方法信息
		}
		
		//动态找到一个方法
		System.out.print("输入方法名:");
		String name = in.nextLine();
		Method m = cls.getDeclaredMethod(name);
		//动态执行方法
		Object val = m.invoke(obj);
		//val 是方法执行以后的返回值
		System.out.println(val); 
	}
}







