SSH?
struts2 + spring + hibernate

day01:struts2简介/消息传递机制/session
day02:Struts2+spring/result类型/拦截器
day03:值栈/Struts2+spring+MyBatis/hibernate简介
day04:ID生成规则/hibernate对象生命周期管理/HQL
day05:struts2 + spring + hibernate

#struts2简介

##是什么?基于MVC设计模式的应用框架

- apache基金会的框架产品

- Struts1/2 mvc设计模式

- Struts2的前身webwork

##什么作用?

表现层框架

- 接收浏览器传递的参数

- 按一定格式返回数据结果

##怎么用?

- 导包-->配置文件-->调用API

- 导包:Struts2-core 2.3.8

- 配置文件:web.xml struts.xml


##struts.xml常用标签

		<package name="" namespace="" extends="">
		<!-- 
		namespace=""  匹配请求路径
		extends="struts-default"  
		 -->
		 <action name="" class="">
		 <!-- 
		 	name=""   匹配具体请求
		 	class=""  指定请求的处理类
		  -->
		  		<result>
		  			<!-- 
					name="" 与请求处理方法匹配
					返回结果处理 -->
		  		</result>
		 </action>
		</package>

#消息传递机制

#什么是?

浏览器与服务器之间数据的传输.

#怎么用?

##浏览器端获取服务器数据
  
  1-控制器中增加属性,增加属性的get方法

  2-在execute方法中给属性赋值

  3-通过EL表达式获取属性数据

##浏览器向服务器传递数据

###基本属性传递方式

1 -在控制器中声明与html表单项name属性一致的Bean属性

2 -针对bean属性,增加setXXX方法

3 -Struts接收请求,会自动将表单数据注入到属性中

###域模型传递方式

####为什么?
  便捷处理表单元素
  表单重用时,优点更加明显

####怎么用?

  1- 对表单元素进行封装--实体类

  2- 在控制中增加实体类对象

  3- 针对对象增加set方法

  4- 实现对象属性的注入


####步骤:

1-User实体类

2-login2.jsp user.username/user.password

3-UserLoginAction{}

4-msg.jsp ${}


##session

session对象的获取方法:

- 工厂方法获取session

- 注入session(重点)

1 - 实现SessionWare

2 - 增加session属性:Map<String,Object> session;

3 - 增加SET/GET方法

4 - session.put(key,value);

#面试题:struts2与springmvc区别?

- struts2 类级别拦截;springMVC 方法级别的拦截;

- 拦截器的实现:struts2--interceptor实现;springMVC--AOP实现

- springMVC方法相对独立,变量之间不共享;struts2方法独立,Action中的变量是共享的.

- struts2 为了线程安全,每个请求创建一个Action处理;比较消耗内存;

- springMVC与spring无缝整合;管理上简单,安全性高;

#作业:

- 搭建struts2使用环境

- 通过基本属性传递实现登录功能

- 通过域模型传递实现登录功能(session使用)












