SSH?
struts2 + spring + hibernate

day01:struts2简介/消息传递机制/session
day02:Struts2+spring/result类型/拦截器
day03:值栈/Struts2+spring+MyBatis/hibernate简介
day04:ID生成规则/hibernate对象生命周期管理/HQL
day05:struts2 + spring + hibernate

#struts2简介

是什么?基于MVC设计模式的应用框架

- apache基金会的框架产品

- Struts1/2 mvc设计模式

- Struts2的前身webwork

什么作用?
表现层框架
- 接收浏览器传递的参数
- 按一定格式返回数据结果

怎么用?








