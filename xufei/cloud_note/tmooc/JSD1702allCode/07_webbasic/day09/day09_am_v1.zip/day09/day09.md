# 一.自定义对象
## 1.直接量(JSON)
- {"name":"zhangsan","age":25}
- {}代表一个对象,内含键值对
- key通常是字符串,value可以是任意类型的数据
> 简单

## 2.构造器(首字母大写的函数)
### 2.1内置构造器
- 特殊: Date, Array, String, RegExp
- 通用: Object

### 2.2自定义构造器

