package day01;

import java.util.Arrays;

public class T {
		public static void main(String[] args) {
			int[] arr = {3,2,8,4,5,6,7};
			int[] newArr = removeArr(arr,5);
			for(int i=0;i<newArr.length;i++){
				System.out.print(newArr[i]);
			}
		}
		public static int[] removeArr(int[] arr,int n){
			int[] newArr = new int[arr.length-1];
			System.arraycopy(arr,0,newArr,0,n);
			System.arraycopy(arr,n+1,newArr,n,arr.length-n-1);
			return newArr;
		}
	}
