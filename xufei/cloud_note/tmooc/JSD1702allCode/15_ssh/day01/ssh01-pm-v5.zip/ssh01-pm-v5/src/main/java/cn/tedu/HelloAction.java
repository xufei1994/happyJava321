package cn.tedu;

public class HelloAction {
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public String execute(){
		System.out.println("Hello World!");
		message="Hi...Hero!!!";
		return "success";
	}
}
