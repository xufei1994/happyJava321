#关联关系

数据库中以主外键的形式体现;实体对象中体现在对象与对象的引用.

User{
id
name
set<Book> books=new HashSet<Book>()   <one-to-many>
}

Book{
id
name
User user <many-to-one>
}

表user(id,name)

表book(id,name,userid)

create table t_user(u_id int not null auto_increment,u_name varchar(30),primary key(u_id))

create table t_book(b_id int not null auto_increment,b_name varchar(30),u_userid int,primary key(b_id))

insert into t_user(u_name) values("Robin")
insert into t_user(u_name) values("Jack")
insert into t_user(u_name) values("Andy")

insert into t_book(b_name,u_userid) values("Oralce",1);
insert into t_book(b_name,u_userid) values("Spring",1);
insert into t_book(b_name,u_userid) values("Struts",1);
insert into t_book(b_name,u_userid) values("Mybatis",1)

案例:

1. 创建实体类TUser/TBook

2. 配置映射文件TUser.hbm.xml/TBook.hbm.xml(重点)

3. 实现测试方法:查询id=1的用户数据

#hibernate的缓存机制

##为什么?

hibernate是持久层的框架,与数据库交互

为了降低应用程序与物理数据源的交互频率,提高应用的运行性能

##工作原理

