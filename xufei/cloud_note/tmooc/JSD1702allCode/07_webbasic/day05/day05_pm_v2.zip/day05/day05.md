# 一.元素的显示方式
## 1.元素有哪些显示方式
### 1)块
- 有宽高,垂直排列
- h1,p,ol,ul,div,table,form

### 2)行内
- 无宽高,左右排列
- span,b,strong,i,em,u,del,a,label

### 3)行内块
- 有宽高,左右排列
- img,input,select,textarea

## 2.如何改变元素的显示方式
- 块: display:block;
- 行内: display:inline;
- 行内块: display:inline-block;
- 隐藏: display:none;

# 二.管理员列表-6
![](1.png)

# 三.计算平方
![](2.png)

# 四.JS调试技巧
## 1.看控制台报错信息
- 不管能否看懂,都必须去看
- 对于反复出现的错误要记住

## 2.打桩
- 跟踪程序执行的过程
- 观察变量的值是否正确

## 3.排除法
- 每次删除一部分代码,看程序还是否报错
- 建议采用二分法,每次删除一半代码
> 此方法适合定位问题

