# 云笔记

## 文件上载

### Ajax 文件上载

利用 FormData 对象和 Spring MVC 配合可以实现Ajax文件上载功能:

	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="UTF-8">
	<title>Insert title here</title>
	<script type="text/javascript" 
		src="scripts/jquery.min.js"></script>
	<script type="text/javascript">
	$(function(){
		$('#upload').click(ajaxUpload);
	});
	function ajaxUpload(){
		var file1 = $('#file1')[0].files[0];
		var file2 = $('#file2')[0].files[0];
		//创建内存中的表单对象
		var form = new FormData();
		//添加向服务器传输的数据
		form.append('userfile1', file1);
		form.append('userfile2', file2);
		
		$.ajax({
			url:'user/upload.do',
			data: form,
			type: 'POST',
			dataType: 'json',
			contentType: false,
			processData: false, 
			success: function(obj){
				if(obj.state==0){
					$('#result').html("成功!"); 
				}
			}
		});
		
	}
	</script>
	</head>
	<body>
		<h1>Ajax 文件上载</h1>
		<input type="file" id="file1"> <br>
		<input type="file" id="file2"> <br>
		<input type="button" id="upload" 
			value="上载" >
		<div id="result"></div>
	</body>
	</html>

## 多参数查询

在MyBatis中, 利用 @Param 注解, 可以实现多参数查询



## 动态SQL


## 翻页功能

