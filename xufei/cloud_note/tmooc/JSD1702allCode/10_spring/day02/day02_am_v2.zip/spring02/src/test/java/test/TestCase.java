package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ioc.A;
import ioc.Manager;

public class TestCase {
	@Test
	public void test1(){
		String config = "ioc.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		A a = ac.getBean("a1",A.class);
		a.execute();
	}
	
	@Test
	public void test2(){
		String config = "ioc.xml";
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				config);
		Manager mg1 = 
				ac.getBean("mg1",Manager.class);
		System.out.println(mg1);
	}
}








