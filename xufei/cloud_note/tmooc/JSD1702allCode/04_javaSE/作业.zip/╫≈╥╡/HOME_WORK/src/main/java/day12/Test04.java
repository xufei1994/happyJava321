package day12;
/**
 * 解析emplist.xml文档，将所有的员工以Emp对象
 * 存入到一个Map中，key为该员工id。
 * 然后要求用户输入一个id，若该员工存在，则输出
 * 该员工入职30周年纪念日。
 * 纪念日为当周的周一的日期。
 * 若该员工不存在，则输出查无此人
 * @author Xiloer
 *
 */
public class Test04 {

}
