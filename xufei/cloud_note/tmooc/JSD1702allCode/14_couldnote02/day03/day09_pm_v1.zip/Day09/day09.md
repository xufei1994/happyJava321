# 云笔记

## AOP 面向切面编程

切面(儿): 事务的横截面

特点: 在不改变软件原有功能情况下为软件插入(扩展)横切面功能.

### 通知

> 目标方法: 被AOP拦截的业务方法, 称为目标方法

切面方法在执行时机：就在目标方法之前, 之后执行.

- @Before: 切面方法在目标方法之前执行
- @After: 切面方法在目标方法之后执行
 
### Around 通知

环绕通知, 可以在业务方法前后调用



### 切入点

用于定位APO的切入位置: 用于指定切入到具体的方法类

- bean组件切入点
	- bean(userService)
	- bean(noteService)
	- bean(userService) || bean(noteService) || bean(notebookService)
	- bean(*Service) 
- 类切入点
	- within(类名)
	- within(类名) || within(类名)
	- within(cn.tedu.note.service.impl.UserServiceImpl)
	- within(cn.tedu.note.*.impl.*ServiceImpl)

- 方法切入点 (execution: 执行)
	- execution(修饰词 类名.方法名(参数类型))
	- execution(* cn.tedu.note.service.UserService.login(..))
	- execution(* cn.tedu.note.*.*Service.list*(..))

> 注意: 一致统一的类和方法的命名规则将有助于编写有效的 切入点表达式!



