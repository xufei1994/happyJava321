package basic;

public class Teacher {

	public Teacher() {
		System.out.println("Teacher()");
	}
	
}
