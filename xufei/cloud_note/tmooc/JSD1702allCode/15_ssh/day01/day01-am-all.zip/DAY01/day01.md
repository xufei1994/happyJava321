SSH?
struts2 + spring + hibernate

day01:struts2简介/消息传递机制/session
day02:Struts2+spring/result类型/拦截器
day03:值栈/Struts2+spring+MyBatis/hibernate简介
day04:ID生成规则/hibernate对象生命周期管理/HQL
day05:struts2 + spring + hibernate

#struts2简介

##是什么?基于MVC设计模式的应用框架

- apache基金会的框架产品

- Struts1/2 mvc设计模式

- Struts2的前身webwork

##什么作用?

表现层框架

- 接收浏览器传递的参数

- 按一定格式返回数据结果

##怎么用?

- 导包-->配置文件-->调用API

- 导包:Struts2-core 2.3.8

- 配置文件:web.xml struts.xml


##struts.xml常用标签

		<package name="" namespace="" extends="">
		<!-- 
		namespace=""  匹配请求路径
		extends="struts-default"  
		 -->
		 <action name="" class="">
		 <!-- 
		 	name=""   匹配具体请求
		 	class=""  指定请求的处理类
		  -->
		  		<result>
		  			<!-- 
					name="" 与请求处理方法匹配
					返回结果处理 -->
		  		</result>
		 </action>
		</package>

#消息传递机制

#什么是?

浏览器与服务器之间数据的传输.

#怎么用?

- 浏览器向服务器传递数据

- 浏览器端获取服务器数据

  1-控制器中增加属性,增加属性的get方法
  2-在execute方法中给属性赋值
  3-通过EL表达式获取属性数据









