# 云笔记

## 文件上载

### Ajax 文件上载

利用 FormData 对象和 Spring MVC 配合可以实现Ajax文件上载功能:

原理: 

![](1.png)

案例:

	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="UTF-8">
	<title>Insert title here</title>
	<script type="text/javascript" 
		src="scripts/jquery.min.js"></script>
	<script type="text/javascript">
	$(function(){
		$('#upload').click(ajaxUpload);
	});
	function ajaxUpload(){
		var file1 = $('#file1')[0].files[0];
		var file2 = $('#file2')[0].files[0];
		//创建内存中的表单对象
		var form = new FormData();
		//添加向服务器传输的数据
		form.append('userfile1', file1);
		form.append('userfile2', file2);
		
		$.ajax({
			url:'user/upload.do',
			data: form,
			type: 'POST',
			dataType: 'json',
			contentType: false,
			processData: false, 
			success: function(obj){
				if(obj.state==0){
					$('#result').html("成功!"); 
				}
			}
		});
		
	}
	</script>
	</head>
	<body>
		<h1>Ajax 文件上载</h1>
		<input type="file" id="file1"> <br>
		<input type="file" id="file2"> <br>
		<input type="button" id="upload" 
			value="上载" >
		<div id="result"></div>
	</body>
	</html>

> 提示: 服务端重用上节课的案例.

## 多参数查询

在MyBatis中, 利用 @Param 注解, 可以实现多参数查询

原理:

![](2.png)

案例:

1. NoteDao接口

		List<Map<String, Object>> findNotes(
			@Param("userId") String userId, 
			@Param("notebookId") String notebookId, 
			@Param("statusId") String statusId);

2. SQL 语句: NoteMapper.xml

		<select id="findNotes" resultType="map">
			select 
				cn_note_id as id,
				cn_note_title as title 
			from 
				cn_note
			<where>
				<if test="userId !=null">
					cn_user_id = #{userId} and
				</if>
				<if test="notebookId != null">
					cn_notebook_id = #{notebookId} and
				</if> 
				cn_note_status_id = #{statusId}
			</where>
			order by
				cn_note_last_modify_time desc
		</select>

## 动态SQL

MyBatis 提供了灵活的动态SQL功能, 只需要使用映射文件的标签就可以到达灵活的拼接SQL语句的功能:

### `<foreach>`

批量删除笔记功能:

原理:

![](3.png)

1. 持久层方法 NoteDao

		int deleteNotes(
			@Param("ids") String... ids);

2. 定义SQL NoteMapper.xml
 
		<delete id="deleteNotes">
			delete from cn_note
			where 
				cn_note_id in 
				<foreach collection="ids"
					item="id"
					open="(" separator="," close=")">
					#{id}
				</foreach>
		</delete>
	
3. 测试 NoteDaoTest

		@Test
		public void testDeleteNotes(){
			String id1="07305c91-d9fa-420d-af09-c3ff209608ff";
			String id2="5565bda4-ddee-4f87-844e-2ba83aa4925f";
			String id3="1ec185d6-554a-481b-b322-b562485bb8e8";
			int n = dao.deleteNotes(id1, id2, id3);
			System.out.println(n); 
		}

## 翻页功能

