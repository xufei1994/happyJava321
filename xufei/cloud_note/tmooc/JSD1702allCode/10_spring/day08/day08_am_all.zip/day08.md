	练习：
	使用MyBatis完成对部门表的增删改查操作。
		a.添加部门信息。
		b.查询出所有部门信息
		c.依据id查询某个部门信息
		d.修改某个部门信息
		e.删除某个部门。
	create table t_dept(
		id number(8) primary key,
		deptName varchar2(20),
		addr varchar2(50)
	);
	create sequence t_dept_seq;

# 1. 返回Map类型的结果
## (1) MyBatis会将记录中的数据先放到一个Map对象里面
	（以字段名作为key,以字段值作为value,一条记录对应一个Map对象），
	然后	再将Map中的数据放到对应的实体对象里面。
![](mybatis.png)

## (2)返回Map类型的结果，好处是不用实体类了，但是不方便
	（因为要获得字段值，还需要调用Map对象提供的get方法,
	注意，oracle数据库中，字段名统一都是大写）。


# 2.解决字段名与实体类的属性名不一致
## (1)方式一  使用别名。(就是让别名与属性名一样)。
## (2)方式二  使用resultMap解决。
![](r1.png)	


