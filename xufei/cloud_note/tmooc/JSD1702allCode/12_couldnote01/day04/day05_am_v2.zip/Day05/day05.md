# 云笔记

## 笔记本列表

### 3. 控制器

1. 添加控制器父类AbstractController, 封装公共的异常处理方法:

		public abstract class AbstractController {
			/**
			 * 在其他控制器方法执行出现异常时候, 执行
			 * 异常处理方法 handleException
			 */
			@ExceptionHandler(Exception.class)
			@ResponseBody
			public Object handleException( Exception e){
				e.printStackTrace();
				return new JsonResult(e);
			}
		
		}

	>重构 UserController, 使其继承于 AbstractController

		略...

2. 创建控制器类 NotebookController:

		@RequestMapping("/notebook")
		@Controller
		public class NotebookController extends AbstractController {
			
			@Resource
			private NotebookService notebookService;
			
			@RequestMapping("/list.do")
			@ResponseBody
			public JsonResult list(String userId){
				List<Map<String, Object>> list=
					notebookService.listNotebooks(userId);
				return new JsonResult(list);
			}
		}

3. 测试

		http://localhost:8080/note/notebook/list.do?userId=52f9b276-38ee-447f-a3aa-0d54e7a736e4

		http://localhost:8080/note/notebook/list.do?userId=abc

		http://localhost:8080/note/notebook/list.do

	> 测试结果体现了控制器能够利用父类的异常处理方法处理异常情况.

### 4. 表现层脚本编程

1. 在edit.html添加JS脚本:



