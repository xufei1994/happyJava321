package day03;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.Test;

import util.DBUtil;

public class TestDay03 {
	
	/**
	 * 批量增加108个员工
	 */
	@Test
	public void test1() {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			conn.setAutoCommit(false);
			
			String sql = 
				"insert into emps values("
				+ "emps_seq.nextval,"
				+ "?,?,?,?,?,?,?)";
			PreparedStatement ps = 
				conn.prepareStatement(sql);
			for(int i=1;i<=108;i++) {
				//将数据暂存到ps对象里
				ps.setString(1, "好汉"+i);
				ps.setString(2, "打劫");
				ps.setInt(3, 0);
				ps.setDate(4, 
					new Date(System.currentTimeMillis()));
				ps.setDouble(5, 6000.0);
				ps.setDouble(6, 8000.0);
				ps.setInt(7, 3);
				ps.addBatch();
				//每50条数据批量提交一次
				if(i%50==0) {
					ps.executeBatch();
					//清空ps中暂存的数据,便于下一批添加
					ps.clearBatch();
				}
			}
			
			//为了避免有零头,再多提交一次
			ps.executeBatch();
			
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtil.rollback(conn);
		} finally {
			DBUtil.close(conn);
		}
	}

	/**
	 * 先增加一个部门,再给此部门增加一个员工.
	 * 要点:增加部门后如何获得生成的部门ID.
	 */
	@Test
	public void test2() {
		//假设页面传入的部门数据是
		String dname = "测试部";
		String loc = "杭州";
		//假设页面传入的员工数据是
		String ename = "八戒";
		String job = "取经";
		int mgr = 0;
		Date hiredate = new Date(
			System.currentTimeMillis());
		double sal = 5000.0;
		double comm = 1000.0;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			conn.setAutoCommit(false);
			
			String sql = 
				"insert into depts values("
				+ "depts_seq.nextval,?,?)";
			
			
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtil.rollback(conn);
		} finally {
			DBUtil.close(conn);
		}
	}
	
}













